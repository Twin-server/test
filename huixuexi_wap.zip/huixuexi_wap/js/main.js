/**
 * Created by Administrator on 2017/7/24.
 */

$(function () {
    if (window.sessionStorage.userId == "") {
      //  $.router.load("#login");
        //13bc970f84e84e6aa24d60d944f5b5ef
    }

    window.name = "test";
    window.sessionStorage.userId = ""; //USER_ID
    window.sessionStorage.userCashId = "";
    window.sessionStorage.courseOrderId = ""; //订单号

    window.sessionStorage.merchantid = "";
    window.sessionStorage.selectproduct = "";
    window.sessionStorage.isquota = "";
    window.sessionStorage.refreshPD = "";
    window.sessionStorage.authorization = "";
    window.sessionStorage.hdId = "";


    window.sessionStorage.Identity = "";//身份
    window.sessionStorage.classId = "";
    window.sessionStorage.classPrice = "";
    window.addEventListener('message',function(e){
        if (typeof (e.data) =='string')  {
            if(e.data.indexOf("?params=") != -1 ){
                checksesameresult (e.data);
            }
        }
    },false);



    $.init();
})

var checkStart = {
    identityCard: "",
    mobileVerify: "",
    otherLinkman: "",
    userMoreVerify: "",
    userSesameF: ""
}
//加载课程列表
$(document).on("pageInit", function(e, pageId, $page) {
    if(pageId == "selectlesson") {
        var url = window.location.href;
        var urlQuery = getQueryObject(url);
        $.ajax({
            type: "post",
            url: javahost4 + "hxx/getCoursewareList",
            data: JSON.stringify({"eduId":"1"}),
            datatype: "json",
            contentType: "application/json;charset=utf-8",
            success: function (data) {
                $("#storeName").html(data.data.eduAddress);
                $("#storeAdd").html(data.data.eduName);
                for (var i = 0; i < data.data.coursewareList.length; i++) {
                    $(".lessonlists").append('<li class="lessonitem blk w100 bddfd"><dl class="blk"><dt class="ft32 col202 crude">' + data.data.coursewareList[i].coursewareName + '</dt><dd class="blk flexbetween mgt10"><div class="w40"><p class="ft48 crude colff6">' + data.data.coursewareList[i].coursewarePrice + '</p><!--<p class="ft26  col808">课程价格</p>--!></div><div class="w30"><p class="ft48 crude col4a4">' + data.data.coursewareList[i].stagesCount + '<span class="ft30 pdl10">期</span></p><p class="ft26 col808">可分期数</p></div><a class="signupbtn w30 ft26 mgt34" external data-price="' + data.data.coursewareList[i].coursewarePrice + '" data-id="' + data.data.coursewareList[i].coursewareId + '">立即分期</a></dd></dl></li>');
                }
            },
            error: function () {
                console.log("请求资源出错了");
            }
        });
    }
});

// 点击申请贷款
$('#application').click(function () {
    const price = $('.price').html();
    const amount = $('.amount').val();
    const stages = $('#staging').val();
    const radio = $("input[name='identity']:checked");

    if(amount == ''){
        $.toast('请输入贷款金额!');
    }else if(Number(amount)>Number(price)){
        $.toast('贷款金额大于课程金额!');
    }else if(stages=='') {
        $.toast('请选择分期数!');
    } else {
        $.ajax({
            url: javahost4 + "hxx/createCoursewareOrder",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                "coursewareId" : window.sessionStorage.classId,
                "identityInfo" : radio.data("identity"),
                "loanAmount" : amount,
                "stagesCount" : stages,
                "turnoverAmount" : price,
                "userId" : window.sessionStorage.userId,
            }),
            success: function(data) {
                if(data.status != 200){
                    $.alert(data.message)
                }else{
                    window.sessionStorage.Identity = radio.val();
                    window.sessionStorage.courseOrderId = data.data.courseOrderId;
                    $.router.load("#completedetails");
                }


            }
        });

    }
})

/*用户信息填写情况预查询*/
$(document).on("pageInit", function(e, pageId, $page) {
    if (pageId == "completedetails") {
        var data = {
            "cashId": window.sessionStorage.userCashId,
            "userId": window.sessionStorage.userId,
            "merchantId": window.sessionStorage.merchantid,
            "type": 0,
            "productType": 1001
        };
        ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": data }, function(D) {
            if (checkAjaxStart(D)) {
                userInfoInit(D);
            }
        });

        var phonedata = {
            "cashId": window.sessionStorage.userCashId,
            "userId": window.sessionStorage.userId,
            "merchantId": window.sessionStorage.merchantid,
            "type": 2,
            "productType": 1001
        };
        ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": phonedata }, function(D) {
            if (checkAjaxStart(D)) {
                $(".isVerified .crude").html(D.data.phone)
            }
        });
    }
});

window.sessionStorage.HANDHELD_ID = 0;
window.sessionStorage.IDCARD_FACADE = 0;
window.sessionStorage.IDACRD_REVERSE = 0;




//身份验证弹窗
$(".isVerified").click(function() {
    var data = {
        "cashId": window.sessionStorage.userCashId,
        "userId": window.sessionStorage.userId,
        "merchantId": window.sessionStorage.merchantid,
        "type": 1,
        "productType": 1001
    };
    ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": data }, function(D) {
        if (checkAjaxStart(D)) {
            $.router.load("#verification1");
            var formItem = $(".usermsg").find("input");
            formItem.eq(0).val(D.data.name);
            formItem.eq(1).val(D.data.idNum);
            formItem.eq(2).val(D.data.idNum);
            formItem.eq(3).val(D.data.bankCard);

        }
    });

    window.sessionStorage.HANDHELD_ID = 0;
    window.sessionStorage.IDCARD_FACADE = 0;
    window.sessionStorage.IDACRD_REVERSE = 0;
    ajax(timelyCfg.api.userFileShowImg, { "data": { "userId": window.sessionStorage.userId } }, function(D) {
        if (checkAjaxStart(D)) {
            if (D.data.filePath.HANDHELD_ID != "") {
                if ($("#frontimg").length >= 1) frontimg.src = D.data.filePath.HANDHELD_ID;
                window.sessionStorage.HANDHELD_ID = 1;
            } else {
                window.sessionStorage.HANDHELD_ID = 0;
            }
            if (D.data.filePath.IDCARD_FACADE != "") {
                if ($("#positivesPic").length >= 1) positivesPic.src = D.data.filePath.IDCARD_FACADE;
                window.sessionStorage.IDCARD_FACADE = 1;
            } else {
                window.sessionStorage.IDCARD_FACADE = 0;
            }
            if (D.data.filePath.IDACRD_REVERSE != "") {
                if ($("#reversesPic").length >= 1) reversesPic.src = D.data.filePath.IDACRD_REVERSE;
                window.sessionStorage.IDACRD_REVERSE = 1;
            } else {
                window.sessionStorage.IDACRD_REVERSE = 0;
            }

        }
    });

});
//基本信息
$(".basicInformation").click(function() {
    // if (!checkStart.identityCard) {
    //     $.alert("请先完善身份验证内的信息哦！");
    //     return false;
    // }

    var data = {
        "cashId": window.sessionStorage.userCashId,
        "userId": window.sessionStorage.userId,
        "merchantId": window.sessionStorage.merchantid,
        "type": 4,
        "productType": 1001
    };
    ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": data }, function(D) {
        if (checkAjaxStart(D)) {
                 $.router.load("#verification2-work");
           var address = D.data.residentInfo.liveAddr;
           var workAddr = D.data.workInfo.workAddr;

            var msg = $("#verification2-work").find("input");
            msg[0].value = address.province + " " + address.city + " " + address.district;
            msg[1].value = D.data.residentInfo.specificAddr;
            msg[2].value = D.data.houseHoldAddress;
            msg[3].value = D.data.annualEarning;
            msg[4].value = D.data.workInfo.workName;
            msg[5].value = workAddr.province + " " + workAddr.city + " " + workAddr.district;
            msg[6].value = D.data.workInfo.specificAddr;
        }
    });
});
//紧急联系人
$("#contactPerson").click(function() {
    // if (!_that.checkStart.identityCard) {
    //     $.alert("请先完善身份验证内的信息哦！");
    //     return false;
    // }s

    var data = {  //window.sessionStorage.userId,
        "cashId": window.sessionStorage.userCashId,
        "userId": window.sessionStorage.userId,
        "merchantId": window.sessionStorage.merchantid,
        "type": 3,
        "productType": 1001
    };
    ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": data }, function(D) {
        if (checkAjaxStart(D)) {
            $.router.load("#verification3");
            if (D.data.contact) {
                var everArr = D.data.contact;

                var relationship = "";
                var relationship2 = "";
                if(everArr[0].relationType == 1){
                    relationship = "夫妻"
                }else if(everArr[0].relationType == 2){
                    relationship = "父母"
                }else if(everArr[0].relationType == 3){
                    relationship = "子女"
                }

                if(everArr[1].relationType == 6){
                    relationship2 = "其他"
                }else if(everArr[1].relationType == 7){
                    relationship2 = "同事"
                }

                $("#andRelation").val(relationship);
                $("#andRelationName").val(everArr[0].name)
                $("#andRelationNum").val(everArr[0].phone)

                $("#friendsRelation").val(relationship2)
                $("#friendName").val(everArr[1].name)
                $("#friendNum").val(everArr[1].phone)


            }
        }
    });
});



//芝麻分授权
$("#userSesameFraction").click(function () {
    // if (!_that.checkStart.identityCard) {
    //     $.alert("请先完善身份验证内的信息哦！");
    //     return false;
    // }
    $.showPreloader();
    var data = {
        "userId": window.sessionStorage.userId
    };
    $.ajax({
        type: "post",
        url: javahostv3 + "collect/zhima/authorize/" + window.sessionStorage.userId,
        data: data,
        datatype: "json",
        contentType: "application/json;charset=utf-8",
        success: function(data) {
            $.hidePreloader(); //显示蒙版层
            if (data.success) {
                var ah5url = data.data;
                $.popup('.popup-user-sesame');
                if (sesameiframe.location.href) {
                    sesameiframe.location.href = ah5url;
                } else {
                    sesameiframe.src = ah5url;
                }
            } else {
                $.alert(data.message);
            }
        },
        //请求出错处理
        error: function() {
            $.hidePreloader(); //显示蒙版层
            $.alert("服务器繁忙");
        }
    })
})

function checksesameresult (data) {
    $.showPreloader();
    var x = data.indexOf("?params=");
    var y = data.indexOf("&sign=");
    var hfstr1 = data.substring(x + 8, y);
    var hfstr2 = data.substring(y + 6);
    $.ajax({
        type: "post",
        url: javahostv3 + "collect/zhima/getOpenId/" + hfstr1 + "/" + hfstr2 ,
        data: data,
        datatype: "json",
        contentType: "application/json;charset=utf-8",
        success: function(data) {
            $.hidePreloader(); //显示蒙版层
            if (data.success) {
                $.alert("芝麻分授权成功！" , function () {
                    $.closeModal('.popup-user-sesame');
                    $(userSesameFraction).find(".icon-f5").addClass("icon-f5-pass");
                    $(userSesameFraction).find(".item-after").addClass("fc1").html("已验证");
                    checkStart.userSesameFra = true;
                });
            } else {
                $.alert(data.message , function (){
                    $.closeModal('.popup-user-sesame');
                });
            }
        },
        //请求出错处理
        error: function() {
            $.hidePreloader(); //显示蒙版层
            $.alert("服务器繁忙");
        }
    })
}

function userInfoInit(D) {
   checkStart = {
        identityCard: D.data.identity,    //身份证
        userMoreVerify: D.data.more,     //更多信息
        otherLinkman: D.data.contact  ,  //联系人
        userSesameF: D.data.zhima        //芝麻分
    }
    userInfoPageShow();
}

function userInfoPageShow() {

    if (checkStart.identityCard) {
        var obj = $(".isVerified");
        obj.find(".whetherIdentity").addClass("littlebtnadd").html("身份证已传");
        obj.find(".whetherName").addClass("littlebtnadd").html("已验证");
    }
    if (checkStart.userMoreVerify) {
        obj = $(".basicInformation");
        obj.find(".whetherInformation").addClass("littlebtnadd").html("已验证");
    }
    if (checkStart.otherLinkman) {
        obj = $(".emergency");
        obj.find(".whetherEmergency").addClass("littlebtnadd").html("已验证");
    }
    if (checkStart.userSesameF) {
        obj = $("#userSesameFraction");
        obj.find(".whetherAuth").addClass("littlebtnadd").html("已验证");
    }

}

$(".signupbtn").live("click", function () {
    var lessonId = $(this).data("id");
    var classprice =  $(this).data("price");
    window.sessionStorage.classId = lessonId;
    window.sessionStorage.classPrice = classprice;
    $.ajax({
        url: "js/test.json",
        type: "GET",
        data: {lessonId: lessonId},
        dataType: "json",
        success: function (data) {
            $.router.load("#confirmation");
        },
        error: function () {
            console.log("请求课程信息出错");
        }
    });
});

//上传手持身份证
$("#frontimg").live("click",function () {
    console.log("上传手持身份证");
    $("#clicktoupload").click();
})
//上传身份证正面
$("#positivesPic").live("click",function () {
    console.log("上传身份证正面");
    $("#positiveupload").click();
})
//上传身份证反面
$("#reversesPic").live("click",function () {
    console.log("上传身份证反面");
    $("#reverseupload").click();
})

//身份证信息获取
var input1 = document.querySelector('#clicktoupload');
var input2 = document.querySelector('#positiveupload');
var input3 = document.querySelector('#reverseupload');

function getCardMsg() {

    if(($("#reportholdidcard li").length == 2) && ($("#positiveBox li").length == 2)){
        $.ajax({
            url: javahost + "user/file/uploadByUserId",
            type: "POST",
            data: JSON.stringify(upLdfrontMsg),
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            success: function (data) {
                var formItem = $(".usermsg").find("input");
                    formItem.eq(0).val(data.name), //姓名
                    formItem.eq(1).val(data.citizenId), //身份证号
                    formItem.eq(2).val(data.validDateEnd)  //证件有效日
            },
            error: function () {
                console.log("请求身份证信息出错");
            }
        });
    }

}

var upLdfrontMsg = {
    "userId": window.sessionStorage.userId,
    "productType" : "1001",
    "ocr" : "1",
    "HANDHELD_ID": {
        facade: 8,
        filename: '1.jpg',
        file: ""
    },
    "IDCARD_FACADE": {
        facade: 1,
        filename: '2.jpg',
        file: ""
    },
    "IDACRD_REVERSE": {
        facade: 2,
        filename: '3.jpg',
        file: ""
    },

};

function clicktouploadchange() {

    if ($("#reportholdidcard li").length == 2) {
        var imgbssixfour1 = frontimg.src;
        imgbssixfour1 = imgbssixfour1.slice(23, imgbssixfour1.length);
        upLdfrontMsg.HANDHELD_ID.file = imgbssixfour1;
    }
}
function positiveuploadchange() {

    if ($("#positiveBox li").length == 2) {
        var imgbssixfour2 = positivesPic.src;
        imgbssixfour2 = imgbssixfour2.slice(23, imgbssixfour2.length);
        upLdfrontMsg.IDCARD_FACADE.file = imgbssixfour2;
    }
}
function reverseuploadchange() {

    if ($("#reverseBox li").length == 2) {
        var imgbssixfour3 = reversesPic.src;
        imgbssixfour3 = imgbssixfour3.slice(23, imgbssixfour3.length);
        upLdfrontMsg.IDACRD_REVERSE.file = imgbssixfour3;
    }
}


input1.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {

            var imgbssixfour1 = holdidcard_report(' ', results.base64, results.base64.length,"#reportholdidcard","frontimg");
            imgbssixfour1 = imgbssixfour1.slice(23, imgbssixfour1.length);
            upLdfrontMsg.HANDHELD_ID.file = imgbssixfour1;
            getCardMsg();
        }
    });

};

input2.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {

            var imgbssixfour2 =holdidcard_report(' ', results.base64, results.base64.length,"#positiveBox","positivesPic");
            imgbssixfour2 = imgbssixfour2.slice(23, imgbssixfour2.length);
            upLdfrontMsg.IDCARD_FACADE.file = imgbssixfour2;
            getCardMsg();
        }
    });


};

input3.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {
           // holdidcard_report(' ', results.base64, results.base64.length,"#reverseBox","reversesPic");
            var imgbssixfour3 =  holdidcard_report(' ', results.base64, results.base64.length,"#reverseBox","reversesPic");
            imgbssixfour3 = imgbssixfour3.slice(23, imgbssixfour3.length);
            upLdfrontMsg.IDACRD_REVERSE.file = imgbssixfour3;
            getCardMsg();
        }
    });

};

function holdidcard_report(title, src, size,id1,id2) {
    var img = new Image(),
        li = document.createElement('div'),
        size = (size / 1024).toFixed(2) + 'KB';
    img.onload = function () {
        var content = '<ul style="display:none">' +
            '<li>' + title + '（' + img.width + ' X ' + img.height + '）</li>' +
            '<li class="text-cyan">' + size + '</li>' +
            '</ul>';
        li.className = 'item';
        li.innerHTML = content;
        li.appendChild(img);
        $(id1).html('');
        document.querySelector(id1).appendChild(li);

    };
    img.setAttribute("id", id2);
    if(id1=="#reportholdidcard"){
        img.className="photo";
    }else{
        img.className="photo2";
    }

    img.src = src;
    return src;

}


//身份证信息获取结束///////////////////////////////////
$("#VerSubmit").click(function () {

    if (window.sessionStorage.HANDHELD_ID == "0") {
        if ($("#reportholdidcard li").length <= 0) {
            $.alert("请上传手持身份证照片哦！");
           // disabled(VerSubmit);
            return false;
        }
    }
    if (window.sessionStorage.IDCARD_FACADE == "0") {
        if ($("#positiveBox li").length <= 0) {
            $.alert("请上传身份证正面照片哦！");
            //disabled(VerSubmit);
            return false;
        }
    }
    if (window.sessionStorage.IDACRD_REVERSE == "0") {
        if ($("#reverseBox li").length <= 0) {
            $.alert("请上传身份证反面照片哦！");
           // disabled(VerSubmit);
            return false;
        }
    }

    var formItem = $(".usermsg").find("input");
    var msgdata = {  //window.sessionStorage.userId
        "productType": "1001",
        "merchantId": window.sessionStorage.merchantid,
        "userId" : "13bc970f84e84e6aa24d60d944f5b5ef",
        "name": formItem.eq(0).val(), //姓名
        "idNum": formItem.eq(1).val(), //身份证号
        "idNumValidDateEnd": formItem.eq(2).val(), //证件有效日期
        "cardNum": formItem.eq(3).val() //银行卡号
    }

    //表单验证
    var msgistrue = checkUserCard(formItem, msgdata);
    if(msgistrue){
        $.ajax({
            url: javahost + "cashloan/submitUserInfo",
            type: "POST",
            data: JSON.stringify(msgdata),
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            success: function (data) {
                //  $.router.load("#login");
            },
            error: function () {
                console.log("请求身份证信息出错");
            }
        });
    }
    
});

//提交订单
$(".submitbtnadd").click(function () {
    var data = {
        "courseOrderId" : window.sessionStorage.courseOrderId,
        "userId" : 　window.sessionStorage.userId
    }


    if (checkStart.identityCard && checkStart.userMoreVerify &&
        checkStart.otherLinkman && checkStart.userSesameF) {
        $.ajax({
            url: javahost4 + "hxx/submitCourseOrder",
            type: "POST",
            data: JSON.stringify(data),
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            success: function (data) {
                if(data.status == 200){
                    $.router.load("#submitted");
                }else {
                    $.toast(data.message);
                }

            },
            error: function () {

            }
        });
    }else{
        $.alert("请完善信息后提交!!!");
    }



})

function checkAjaxStart(D) {
    if (D.success == true) {
        return true;
    } else {
        $.alert(D.message);
        return false;
    }
}

//获取URL参数
function getQueryObject(url) {
    url = url == null ? window.location.href : url;
    var search = url.substring(url.lastIndexOf("?") + 1);
    var obj = {};
    var reg = /([^?&=]+)=([^?&=]*)/g;
    search.replace(reg, function (rs, $1, $2) {
        var name = decodeURIComponent($1);
        var val = decodeURIComponent($2);
        val = String(val);
        obj[name] = val;
        return rs;
    });
    return obj;
}


//数字千位格式化  3,000,000
function toThousands(num) {
    var result = [ ], counter = 0;
    num = (num || 0).toString().split('');
    for (var i = num.length - 1; i >= 0; i--) {
        counter++;
        result.unshift(num[i]);
        if (!(counter % 3) && i != 0) { result.unshift(','); }
    }
    return result.join('');
}

// --------验证类方法-------


function checkUserCard(formItem, data) {
    //姓名
    if (data.name == "") {
        $.alert(msg.userName.empty, function() {
            formItem.eq(0).focus();
        });
        return false;
    }

    if (!this.checkRealname2(data.name)) {
        $.alert(msg.userName.error, function() {
            formItem.eq(0).focus();
        });
        return false;
    }
    //身份证号
    if (data.idNum == "") {
        $.alert(msg.idNum.empty, function() {
            formItem.eq(1).focus();
        });
        return false;
    }
    if (!this.checkIdcard2(data.idNum)) {
        $.alert(msg.idNum.error, function() {
            formItem.eq(1).focus();
        });
        return false;
    }
    //身份证有效日期
    if (data.idNumValidDateEnd == "") {
        $.alert(msg.idData.empty, function() {
            formItem.eq(2).focus();
        });
        return false;
    }
    //银行卡号
    if (data.cardNum == "") {
        $.alert(msg.cardNum.empty, function() {
            formItem.eq(3).focus();
        });
        return false;
    }
    if (!this.checkBanknumber2(data.cardNum)) {
        $.alert(msg.cardNum.error, function() {
            formItem.eq(3).focus();
        });
        return false;
    }

    return true;
};





//真实姓名有效性校验
function checkRealname(humanName) {
    if (humanName.value == "") {
        $.alert('请输入正确的真实姓名哦', function() {
            humanName.focus();
        });
    } else {
        var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/;
        if (regName.test(humanName.value) !== true) {
            return false;
        } else {
            return true;
        }
    }
};
//姓名有效性校验
function checkRealname2(humanName) {
    var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/
    return regName.test(humanName);
};


//严格身份证号码校验
function checkIdcard2(humanId) {
    humanId = humanId.replace('x', 'X');
    var vcity = {
        11: "北京",
        12: "天津",
        13: "河北",
        14: "山西",
        15: "内蒙古",
        21: "辽宁",
        22: "吉林",
        23: "黑龙江",
        31: "上海",
        32: "江苏",
        33: "浙江",
        34: "安徽",
        35: "福建",
        36: "江西",
        37: "山东",
        41: "河南",
        42: "湖北",
        43: "湖南",
        44: "广东",
        45: "广西",
        46: "海南",
        50: "重庆",
        51: "四川",
        52: "贵州",
        53: "云南",
        54: "西藏",
        61: "陕西",
        62: "甘肃",
        63: "青海",
        64: "宁夏",
        65: "新疆",
        71: "台湾",
        81: "香港",
        82: "澳门",
        91: "国外"
    };
    var regId = /(^\d{17}(\d|X)$)/;
    var province = humanId.substr(0, 2);
    var len = humanId.length;
    var re_eighteen = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/;
    var arr_data = humanId.match(re_eighteen);
    if (regId.test(humanId) == false) {
        return false; //校验位数；
    } else if (vcity[province] == undefined) {
        return false; //校验城市
    } else if (regId.test(humanId) !== false) {
        var year = arr_data[2];
        var month = arr_data[3];
        var day = arr_data[4];
        var birthday = new Date(year + '/' + month + '/' + day);
        var now = new Date();
        var now_year = now.getFullYear();
        var time = now_year - year;
        if (birthday.getFullYear() == year && (birthday.getMonth() + 1) == month && birthday.getDate() == day) {
            if (time >= 3 && time <= 100) {
                var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                var cardTemp = 0,
                    i, valnum;
                for (i = 0; i < 17; i++) {
                    cardTemp += humanId.substr(i, 1) * arrInt[i];
                }
                valnum = arrCh[cardTemp % 11];
                if (valnum == humanId.substr(17, 1)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return false;
    }
}


//严格版银行卡卡号校验（16-19位）
function checkBanknumber2(bankCard) {
    var num = /^\d*$/;
    var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
    if (bankCard.length < 16 || bankCard.length > 19) {
        return false; //位数
    } else if (!num.exec(bankCard)) {
        return false; //数字
    } else if (strBin.indexOf(bankCard.substring(0, 2)) == -1) {
        return false; //前6位校验
    } else {
        var lastNum = bankCard.substr(bankCard.length - 1, 1); //取出最后一位（与luhm进行比较）
        var first15Num = bankCard.substr(0, bankCard.length - 1); //前15或18位
        var newArr = new Array();
        for (var i = first15Num.length - 1; i > -1; i--) { //前15或18位倒序存进数组
            newArr.push(first15Num.substr(i, 1));
        }
        var arrJiShu = new Array(); //奇数位*2的积 <9
        var arrJiShu2 = new Array(); //奇数位*2的积 >9
        var arrOuShu = new Array(); //偶数位数组
        for (var j = 0; j < newArr.length; j++) {
            if ((j + 1) % 2 == 1) { //奇数位
                if (parseInt(newArr[j]) * 2 < 9)
                    arrJiShu.push(parseInt(newArr[j]) * 2);
                else
                    arrJiShu2.push(parseInt(newArr[j]) * 2);
            } else //偶数位
                arrOuShu.push(newArr[j]);
        }
        var jishu_child1 = new Array(); //奇数位*2 >9 的分割之后的数组个位数
        var jishu_child2 = new Array(); //奇数位*2 >9 的分割之后的数组十位数
        for (var h = 0; h < arrJiShu2.length; h++) {
            jishu_child1.push(parseInt(arrJiShu2[h]) % 10);
            jishu_child2.push(parseInt(arrJiShu2[h]) / 10);
        }
        var sumJiShu = 0; //奇数位*2 < 9 的数组之和
        var sumOuShu = 0; //偶数位数组之和
        var sumJiShuChild1 = 0; //奇数位*2 >9 的分割之后的数组个位数之和
        var sumJiShuChild2 = 0; //奇数位*2 >9 的分割之后的数组十位数之和
        var sumTotal = 0;
        for (var m = 0; m < arrJiShu.length; m++) {
            sumJiShu = sumJiShu + parseInt(arrJiShu[m]);
        }
        for (var n = 0; n < arrOuShu.length; n++) {
            sumOuShu = sumOuShu + parseInt(arrOuShu[n]);
        }
        for (var p = 0; p < jishu_child1.length; p++) {
            sumJiShuChild1 = sumJiShuChild1 + parseInt(jishu_child1[p]);
            sumJiShuChild2 = sumJiShuChild2 + parseInt(jishu_child2[p]);
        }
        //计算总和
        sumTotal = parseInt(sumJiShu) + parseInt(sumOuShu) + parseInt(sumJiShuChild1) + parseInt(sumJiShuChild2);
        //计算Luhm值
        var k = parseInt(sumTotal) % 10 == 0 ? 10 : parseInt(sumTotal) % 10;
        var luhm = 10 - k;
        if (lastNum == luhm) {
            return true;
        }
    }
    return false;
}


function ajax(url, opts, callBack, errorBack) {
    opts = opts || {};

    $.ajax({
        url: url,
        type: opts.type || 'POST',
        data: JSON.stringify(opts.data) || {},
        dataType: opts.dataType || 'json',
        contentType: "application/json",
        async: opts.async || true,
        success: callBack || ajaxBack,
        error: function(D) {
            ajaxNone(D);
            if (errorBack) errorBack();
        }
    });
}

function ajaxNone() {
    $.alert("系统错误请稍后再试！");
    return false;
}

function ajaxBack(D) {
    $.alert("系统错误请稍后再试！");
    return false;
}


