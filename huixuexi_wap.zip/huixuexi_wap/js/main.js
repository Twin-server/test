/**
 * Created by Administrator on 2017/7/24.
 */

$(function () {
    if (window.sessionStorage.phcdgo == "") {
      //  $.router.load("#login");
    }

    window.sessionStorage.phcdgo = "";
    window.sessionStorage.userId = "";
    $(document).on("pageInit", function(e, pageId, $page) {
        if(pageId == "selectlesson") {
            var url = window.location.href;
            var urlQuery = window.util.getQueryObject(url);
            $.ajax({
                url: "js/test.json",
                type: "GET",
                data: {cid: 12},
                dataType: "json",
                success: function (data) {
                    for (var i = 0; i < data.length; i++) {
                        $(".lessonlists").append('<li class="lessonitem blk w100 bddfd"><dl class="blk"><dt class="ft32 col202 crude">' + data[i].coursewareName + '</dt><dd class="blk flexbetween mgt10"><div class="w40"><p class="ft48 crude colff6">' + data[i].coursewarePrice + '<span class="ft28 crude">.00</span></p><p class="ft26  col808">课程价格</p></div><div class="w30"><p class="ft48 crude col4a4">' + data[i].stagesCount + '<span class="ft30 pdl10">期</span></p><p class="ft26 col808">可分期数</p></div><a class="signupbtn w30 ft26 mgt34" href="#confirmation" external data-id="' + data[i].coursewareId + '">立即分期</a></dd></dl></li>');
                    }

                },
                error: function () {
                    console.log("请求资源出错了");
                }
            });
        }
    });

    $(document).on("pageInit", function(e, pageId, $page) {
        //verification1
        if(pageId == "11213213") {
            $.ajax({
                url: timelyCfg.api.userFileShowImg,
                type: "post",
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify({
                    productType: 1001,
                    userId : window.sessionStorage.userId
                }),
                success: function(D) {
                    if (checkAjaxStart(D)) {
                        if (D.data.filePath.HANDHELD_ID != "") {
                            if ($("#frontimg").length >= 1)
                                frontimg.src = D.data.filePath.HANDHELD_ID;
                            window.sessionStorage.HANDHELD_ID = 1;
                        } else {
                            window.sessionStorage.HANDHELD_ID = 0;
                        }
                        if (D.data.filePath.IDCARD_FACADE != "") {
                            if ($("#positivesPic").length >= 1)
                                positivesPic.src = D.data.filePath.IDCARD_FACADE;
                            window.sessionStorage.IDCARD_FACADE = 1;
                        } else {
                            window.sessionStorage.IDCARD_FACADE = 0;
                        }
                        if (D.data.filePath.IDACRD_REVERSE != "") {
                            if ($("#reversesPic").length >= 1)
                                reversesPic.src = D.data.filePath.IDACRD_REVERSE;
                            window.sessionStorage.IDACRD_REVERSE = 1;
                        } else {
                            window.sessionStorage.IDACRD_REVERSE = 0;
                        }
                    }
                }
            });
        }
    });

    $.init();
})

$(".signupbtn").live("click", function () {
    var lessonId = $(this).data("id");
    $.ajax({
        url: "js/test.json",
        type: "GET",
        data: {lessonId: lessonId},
        dataType: "json",
        success: function (data) {
            $.router.load("#confirmation");
        },
        error: function () {
            console.log("请求课程信息出错");
        }
    });
});

//上传手持身份证
$("#frontimg").live("click",function () {
    console.log("上传手持身份证");
    $("#clicktoupload").click();
})
//上传身份证正面
$("#positivesPic").live("click",function () {
    console.log("上传身份证正面");
    $("#positiveupload").click();
})
//上传身份证反面
$("#reversesPic").live("click",function () {
    console.log("上传身份证反面");
    $("#reverseupload").click();
})

//身份证信息获取
var input1 = document.querySelector('#clicktoupload');
var input2 = document.querySelector('#positiveupload');
var input3 = document.querySelector('#reverseupload');

function getCardMsg() {

    if(($("#reportholdidcard li").length == 2) && ($("#positiveBox li").length == 2) && ($("#reverseBox li").length == 2)){
        $.ajax({
            url: "js/test.json",
            type: "GET",
            data: {upLdfrontMsg: upLdfrontMsg},
            dataType: "json",
            success: function (data) {
                var formItem = $(".usermsg").find("input");
                formItem.eq(0).val(), //姓名
                    formItem.eq(1).val(), //身份证号
                    formItem.eq(2).val(), //证件有效日期
                    formItem.eq(3).val()  //证件有效日期
            },
            error: function () {
                console.log("请求身份证信息出错");
            }
        });
    }

}

var upLdfrontMsg = {
    // "cashId": window.sessionStorage.userCashId,
    // "userId": window.sessionStorage.userId,
    "HANDHELD_ID": {
        facade: 8,
        filename: '1.jpg',
        file: ""
    },
    "IDCARD_FACADE": {
        facade: 1,
        filename: '2.jpg',
        file: ""
    },
    "IDACRD_REVERSE": {
        facade: 2,
        filename: '3.jpg',
        file: ""
    },

};

function clicktouploadchange() {
    getCardMsg();
    if ($("#reportholdidcard li").length == 2) {
        var imgbssixfour1 = frontimg.src;
        imgbssixfour1 = imgbssixfour1.slice(23, imgbssixfour1.length);
        upLdfrontMsg.HANDHELD_ID.file = imgbssixfour1;
    }
}
function positiveuploadchange() {
    getCardMsg();
    if ($("#positiveBox li").length == 2) {
        var imgbssixfour2 = positivesPic.src;
        imgbssixfour2 = imgbssixfour2.slice(23, imgbssixfour2.length);
        upLdfrontMsg.IDCARD_FACADE.file = imgbssixfour2;
    }
}
function reverseuploadchange() {
    getCardMsg();
    if ($("#reverseBox li").length == 2) {
        var imgbssixfour3 = reversesPic.src;
        imgbssixfour3 = imgbssixfour3.slice(23, imgbssixfour3.length);
        upLdfrontMsg.IDACRD_REVERSE.file = imgbssixfour3;
    }
}


input1.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {
            holdidcard_report(' ', results.base64, results.base64.length,"#reportholdidcard","frontimg",clicktouploadchange);
        }
    });
    getCardMsg();
    if ($("#reportholdidcard li").length == 2) {
        var imgbssixfour1 = frontimg.src;
        imgbssixfour1 = imgbssixfour1.slice(23, imgbssixfour1.length);
        upLdfrontMsg.HANDHELD_ID.file = imgbssixfour1;
    }
};

input2.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {
            holdidcard_report(' ', results.base64, results.base64.length,"#positiveBox","positivesPic",positiveuploadchange);
        }
    });
    getCardMsg();
    if ($("#positiveBox li").length == 2) {
        var imgbssixfour2 = positivesPic.src;
        imgbssixfour2 = imgbssixfour2.slice(23, imgbssixfour2.length);
        upLdfrontMsg.IDCARD_FACADE.file = imgbssixfour2;
    }
};
input3.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {
            holdidcard_report(' ', results.base64, results.base64.length,"#reverseBox","reversesPic",reverseuploadchange);
        }
    });
    getCardMsg();
    if ($("#reverseBox li").length == 2) {
        var imgbssixfour3 = reversesPic.src;
        imgbssixfour3 = imgbssixfour3.slice(23, imgbssixfour3.length);
        upLdfrontMsg.IDACRD_REVERSE.file = imgbssixfour3;
    }
};

function holdidcard_report(title, src, size,id1,id2,fn) {
    var img = new Image(),
        li = document.createElement('div'),
        size = (size / 1024).toFixed(2) + 'KB';
    img.onload = function () {
        var content = '<ul style="display:none">' +
            '<li>' + title + '（' + img.width + ' X ' + img.height + '）</li>' +
            '<li class="text-cyan">' + size + '</li>' +
            '</ul>';
        li.className = 'item';
        li.innerHTML = content;
        li.appendChild(img);
        $(id1).html('');
        document.querySelector(id1).appendChild(li);
        fn();
    };
    img.setAttribute("id", id2);
    if(id1=="#reportholdidcard"){
        img.className="photo";
    }else{
        img.className="photo2";
    }

    img.src = src;
}


//身份证信息获取结束///////////////////////////////////

var VerSubmit = $("#VerSubmit");
VerSubmit.click(function () {

    // if (window.sessionStorage.HANDHELD_ID == "0") {
    //     if ($("#reportholdidcard li").length <= 0) {
    //         $.alert("请上传手持身份证照片哦！");
    //         //  _that.disabled(VerSubmit);
    //         return false;
    //     }
    // }
    // if (window.sessionStorage.IDCARD_FACADE == "0") {
    //     if ($("#positiveBox li").length <= 0) {
    //         $.alert("请上传身份证正面照片哦！");
    //         // _that.disabled(VerSubmit);
    //         return false;
    //     }
    // }
    // if (window.sessionStorage.IDACRD_REVERSE == "0") {
    //     if ($("#reverseBox li").length <= 0) {
    //         $.alert("请上传身份证反面照片哦！");
    //         //  _that.disabled(VerSubmit);
    //         return false;
    //     }
    // }

    var formItem = $(".usermsg").find("input");
    var data = {
        "VerUserName": formItem.eq(0).val(), //姓名
        "VerCardId": formItem.eq(1).val(), //身份证号
        "VerEffectiveDate": formItem.eq(2).val(), //证件有效日期
        "VerbankId": formItem.eq(3).val() //银行卡号
    }
    //表单验证
    var msgistrue = checkUserCard(formItem, data);

    window.sessionStorage.HANDHELD_ID = 0;
    window.sessionStorage.IDCARD_FACADE = 0;
    window.sessionStorage.IDACRD_REVERSE = 0;

});

function checkAjaxStart(D) {
    if (D.success == true) {
        return true;
    } else {
        $.alert(D.message);
        return false;
    }
}

//获取URL参数
function getQueryObject(url) {
    url = url == null ? window.location.href : url;
    var search = url.substring(url.lastIndexOf("?") + 1);
    var obj = {};
    var reg = /([^?&=]+)=([^?&=]*)/g;
    search.replace(reg, function (rs, $1, $2) {
        var name = decodeURIComponent($1);
        var val = decodeURIComponent($2);
        val = String(val);
        obj[name] = val;
        return rs;
    });
    return obj;
}


//数字千位格式化  3,000,000
function toThousands(num) {
    var result = [ ], counter = 0;
    num = (num || 0).toString().split('');
    for (var i = num.length - 1; i >= 0; i--) {
        counter++;
        result.unshift(num[i]);
        if (!(counter % 3) && i != 0) { result.unshift(','); }
    }
    return result.join('');
}

// --------验证类方法-------


function checkUserCard(formItem, data) {
    //姓名
    if (data.VerUserName == "") {
        $.alert(msg.userName.empty, function() {
            formItem.eq(0).focus();
        });
        return false;
    }

    if (!this.checkRealname2(data.VerUserName)) {
        $.alert(msg.userName.error, function() {
            formItem.eq(0).focus();
        });
        return false;
    }
    //身份证号
    if (data.VerCardId == "") {
        $.alert(msg.idNum.empty, function() {
            formItem.eq(1).focus();
        });
        return false;
    }
    if (!checkIdcard2(data.VerCardId)) {
        $.alert(msg.idNum.error, function() {
            formItem.eq(1).focus();
        });
        return false;
    }
    //身份证有效日期
    if (data.VerEffectiveDate == "") {
        $.alert(msg.idData.empty, function() {
            formItem.eq(2).focus();
        });
        return false;
    }
    //银行卡号
    if (data.VerbankId == "") {
        $.alert(msg.cardNum.empty, function() {
            formItem.eq(3).focus();
        });
        return false;
    }
    if (!checkBanknumber2(data.VerbankId)) {
        $.alert(msg.cardNum.error, function() {
            formItem.eq(3).focus();
        });
        return false;
    }

    return true;
};





//真实姓名有效性校验
function checkRealname(humanName) {
    if (humanName.value == "") {
        $.alert('请输入正确的真实姓名哦', function() {
            humanName.focus();
        });
    } else {
        var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/;
        if (regName.test(humanName.value) !== true) {
            return false;
        } else {
            return true;
        }
    }
};
//姓名有效性校验
function checkRealname2(humanName) {
    var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/
    return regName.test(humanName);
};


//严格身份证号码校验
function checkIdcard2(humanId) {
    humanId = humanId.replace('x', 'X');
    var vcity = {
        11: "北京",
        12: "天津",
        13: "河北",
        14: "山西",
        15: "内蒙古",
        21: "辽宁",
        22: "吉林",
        23: "黑龙江",
        31: "上海",
        32: "江苏",
        33: "浙江",
        34: "安徽",
        35: "福建",
        36: "江西",
        37: "山东",
        41: "河南",
        42: "湖北",
        43: "湖南",
        44: "广东",
        45: "广西",
        46: "海南",
        50: "重庆",
        51: "四川",
        52: "贵州",
        53: "云南",
        54: "西藏",
        61: "陕西",
        62: "甘肃",
        63: "青海",
        64: "宁夏",
        65: "新疆",
        71: "台湾",
        81: "香港",
        82: "澳门",
        91: "国外"
    };
    var regId = /(^\d{17}(\d|X)$)/;
    var province = humanId.substr(0, 2);
    var len = humanId.length;
    var re_eighteen = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/;
    var arr_data = humanId.match(re_eighteen);
    if (regId.test(humanId) == false) {
        return false; //校验位数；
    } else if (vcity[province] == undefined) {
        return false; //校验城市
    } else if (regId.test(humanId) !== false) {
        var year = arr_data[2];
        var month = arr_data[3];
        var day = arr_data[4];
        var birthday = new Date(year + '/' + month + '/' + day);
        var now = new Date();
        var now_year = now.getFullYear();
        var time = now_year - year;
        if (birthday.getFullYear() == year && (birthday.getMonth() + 1) == month && birthday.getDate() == day) {
            if (time >= 3 && time <= 100) {
                var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                var cardTemp = 0,
                    i, valnum;
                for (i = 0; i < 17; i++) {
                    cardTemp += humanId.substr(i, 1) * arrInt[i];
                }
                valnum = arrCh[cardTemp % 11];
                if (valnum == humanId.substr(17, 1)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return false;
    }
}


//严格版银行卡卡号校验（16-19位）
function checkBanknumber2(bankCard) {
    var num = /^\d*$/;
    var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
    if (bankCard.length < 16 || bankCard.length > 19) {
        return false; //位数
    } else if (!num.exec(bankCard)) {
        return false; //数字
    } else if (strBin.indexOf(bankCard.substring(0, 2)) == -1) {
        return false; //前6位校验
    } else {
        var lastNum = bankCard.substr(bankCard.length - 1, 1); //取出最后一位（与luhm进行比较）
        var first15Num = bankCard.substr(0, bankCard.length - 1); //前15或18位
        var newArr = new Array();
        for (var i = first15Num.length - 1; i > -1; i--) { //前15或18位倒序存进数组
            newArr.push(first15Num.substr(i, 1));
        }
        var arrJiShu = new Array(); //奇数位*2的积 <9
        var arrJiShu2 = new Array(); //奇数位*2的积 >9
        var arrOuShu = new Array(); //偶数位数组
        for (var j = 0; j < newArr.length; j++) {
            if ((j + 1) % 2 == 1) { //奇数位
                if (parseInt(newArr[j]) * 2 < 9)
                    arrJiShu.push(parseInt(newArr[j]) * 2);
                else
                    arrJiShu2.push(parseInt(newArr[j]) * 2);
            } else //偶数位
                arrOuShu.push(newArr[j]);
        }
        var jishu_child1 = new Array(); //奇数位*2 >9 的分割之后的数组个位数
        var jishu_child2 = new Array(); //奇数位*2 >9 的分割之后的数组十位数
        for (var h = 0; h < arrJiShu2.length; h++) {
            jishu_child1.push(parseInt(arrJiShu2[h]) % 10);
            jishu_child2.push(parseInt(arrJiShu2[h]) / 10);
        }
        var sumJiShu = 0; //奇数位*2 < 9 的数组之和
        var sumOuShu = 0; //偶数位数组之和
        var sumJiShuChild1 = 0; //奇数位*2 >9 的分割之后的数组个位数之和
        var sumJiShuChild2 = 0; //奇数位*2 >9 的分割之后的数组十位数之和
        var sumTotal = 0;
        for (var m = 0; m < arrJiShu.length; m++) {
            sumJiShu = sumJiShu + parseInt(arrJiShu[m]);
        }
        for (var n = 0; n < arrOuShu.length; n++) {
            sumOuShu = sumOuShu + parseInt(arrOuShu[n]);
        }
        for (var p = 0; p < jishu_child1.length; p++) {
            sumJiShuChild1 = sumJiShuChild1 + parseInt(jishu_child1[p]);
            sumJiShuChild2 = sumJiShuChild2 + parseInt(jishu_child2[p]);
        }
        //计算总和
        sumTotal = parseInt(sumJiShu) + parseInt(sumOuShu) + parseInt(sumJiShuChild1) + parseInt(sumJiShuChild2);
        //计算Luhm值
        var k = parseInt(sumTotal) % 10 == 0 ? 10 : parseInt(sumTotal) % 10;
        var luhm = 10 - k;
        if (lastNum == luhm) {
            return true;
        }
    }
    return false;
}