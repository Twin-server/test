
var javahost = "https://api.credan.com/v2/"; //正式
var javahostv3 = "https://api.credan.com/v3/"; //正式
var javahost2 = "https://consumer.credan.com/";
var timelyCfg = {
    api: {
        cashloantestMessage: javahost + 'cashloan/submitOrderInfo',
        cashloanQueryUserInfo: javahost + 'cashloan/queryUserInfo',
        cashloanSubmitUserInfo: javahost + 'cashloan/submitUserInfo',
        cashloanSubmitContactInfo: javahost + 'cashloan/submitContactInfo',
        cashloanSubmitDetailInfo: javahost + 'cashloan/submitDetailInfo',
        cashloanFinalSubmit: javahost + 'cashloan/finalSubmit',
        collectionMobileSubmit: javahost + "user/collection/mobile/submit",
        userFileUploadByUserId: javahost + "user/file/uploadByUserId",
        userFileShowImg: javahost + 'user/file/showImg'
    }
}


var reclickTime =60;


// ===获取短信验证码
$("#getPhcodebtn").click(function() {
    var checkresult = checkPhonenum(phoneNum);
    if (checkresult == true) {
        sendCode(this);
        $.ajax({
            url: javahost2 + "wx/enrollSendCode",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                phone: $('#phoneNum').val()
            }),
            success: function(data) {
                if (data.statusCode == 10001) {
                    window.sessionStorage.phcdgo = 10001;
                    $.alert("发送成功！");
                } else {
                    if (data.statusCode == 10002) {
                        if (data.data.userStatus == "REJECT") {

                        } else {
                            $.alert(data.message);
                        }
                    }
                }

            }
        });
    }
});

// ===注册
$("#regandloginbtn").click(function() {
    var checkresult = checkPhonenum(phoneNum);
    var verificationCode = document.getElementById("verificationCode").value;
    if(checkresult == true){
        $.router.load("#selectlesson");
        if(verificationCode != "") {
            $.ajax({
                url: javahost2 + "wx/userEnrollCode",
                type: "post",
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify({
                    phone: $('#phoneNum').val(),
                    code : $("#verificationCode").val()
                }),
                success: function(data) {
                    window.sessionStorage.userId = data.userId;

                }
            });
        }else{
            $.alert("请输入验证码")
        }


    }
});



// ==发送短信验证
function sendCode(thisBtn) {
    thisBtn.setAttribute("disabled", "true");
    thisBtn.style.background = "#bababa";
    thisBtn.style.color = "#fff";
    thisBtn.value = reclickTime + "秒后重获";
    resetButton = setInterval(doLoop, 1000, thisBtn);
}

function doLoop(thisBtn) {
    reclickTime--;
    if (reclickTime > 0) {
        thisBtn.value = reclickTime + "秒后重获";
    } else {
        clearInterval(resetButton);
        thisBtn.disabled = false;
        thisBtn.style.background = "#fe813c";
        thisBtn.style.color = "#fff";
        thisBtn.value = "获取验证码";
        reclickTime = 60;
    }
}



//公用方法：较验手机号有效性
function checkPhonenum(phoneNum) {
    if (phoneNum.value == "") {
        $.alert('请输入正确的手机号哦', function () {
            phoneNum.focus();
        });
        return false;
    } else if (phoneNum.value !== "") {
        var reg0 = /^13\d{5,9}$/;
        var reg1 = /^15\d{5,9}$/;
        var reg2 = /^17\d{5,9}$/;
        //      var reg3 = /^0\d{10,11}$/;
        var reg3 = /^14\d{5,9}$/;
        var reg4 = /^18\d{5,9}$/;
        var my = false;
        if (reg0.test(phoneNum.value)) my = true;
        if (reg1.test(phoneNum.value)) my = true;
        if (reg2.test(phoneNum.value)) my = true;
        //      if (reg3.test(phoneNum.value))my=true;
        if (reg3.test(phoneNum.value)) my = true;
        if (reg4.test(phoneNum.value)) my = true;
        if (!my) {
            $.alert('请输入正确的手机号哦', function () {
                phoneNum.value = "";
                phoneNum.focus();
            });
            return false;
        }
        return true;
    }
}


