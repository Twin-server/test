/**
 * Created by Administrator on 2017/7/27.
 */


var javahost = "http://118.190.67.197:8070/v2/"; //开发URL
var javahostv3 = "http://118.190.67.197:8070/v3/"; //开发URL
var javahost2 = "http://118.190.67.197:8030/"; //开发URL

var javahost4 = "http://118.190.67.197:8080/"; //开发URL

/*
 var javahost = "http://118.190.60.163:8070/v2/"; //预发布URL
 var javahostv3 = "http://118.190.60.163:8070/v3/"; //预发布URL
 var javahost2 = "http://118.190.60.163:8030/"; //预发布URL
 */


// var javahost = "https://api.credan.com/v2/"; //正式
// var javahostv3 = "https://api.credan.com/v3/"; //正式
// var javahost2 = "https://consumer.credan.com/";

// var javahost = "http://192.168.1.100:8080/"; //预发布URL
// var javahostv3 = "http://192.168.1.100:8080/"; //预发布URL
// var javahost2 = "http://192.168.1.100:8080/"; //预发布URL

var timelyCfg = {
    api: {
        cashloantestMessage: javahost + 'cashloan/submitOrderInfo',
        cashloanQueryUserInfo: javahost + 'cashloan/queryUserInfo',
        cashloanSubmitUserInfo: javahost + 'cashloan/submitUserInfo',
        cashloanSubmitContactInfo: javahost + 'cashloan/submitContactInfo',
        cashloanSubmitDetailInfo: javahost + 'cashloan/submitDetailInfo',
        cashloanFinalSubmit: javahost + 'cashloan/finalSubmit',
        collectionMobileSubmit: javahost + "user/collection/mobile/submit",
        userFileUploadByUserId: javahost + "user/file/uploadByUserId",
        userFileShowImg: javahost + 'user/file/showImg'
    }
}


var reclickTime =60;


//发起call类
//CALL接口获取验证码并在60秒内不可再次点击
var handlerPopup = function(captchaObj) {
    captchaObj.onReady(function() {
        captchaObj.show();
    });
    // 成功的回调
    captchaObj.onSuccess(function() {
        var validate = captchaObj.getValidate();
        $.ajax({
            url: javahost2 + "wx/enrollSendCode", // 进行二次验证
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                phone: $('#phoneNum').val(),
                geetest_challenge: validate.geetest_challenge,
                geetest_validate: validate.geetest_validate,
                geetest_seccode: validate.geetest_seccode
            }),
            success: function(data) {
                if (data.statusCode == 10001) {
                    window.sessionStorage.phcdgo = 10001;
                    $.toast("发送成功！");
                } else {
                    $.alert(data.message);
                }

            }
        });
    });

    // 将验证码加到id为captcha的元素里
    captchaObj.appendTo("#popup-captcha");
    // 更多接口参考：http://www.geetest.com/install/sections/idx-client-sdk.html
};

var phoneNum = document.getElementById("phoneNum");
$("#getPhcodebtn").click(function() {
    var checkresult = checkPhonenum(phoneNum);
    if (checkresult == true) {
        sendCode(this);
        // 验证开始需要向网站主后台获取id，challenge，success（是否启用failback）
        $.ajax({
            url: javahost2 + "wx/smsCaptcha",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                phone: $('#phoneNum').val(),
            }),
            success: function(data) {
                // 使用initGeetest接口
                // 参数1：配置参数
                // 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
                initGeetest({
                    gt: data.gt,
                    https: true,
                    challenge: data.challenge,
                    product: "popup", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
                    offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
                    // 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
                }, handlerPopup);
            }
        });
    } else {

    }
});

// ===注册
$("#regandloginbtn").click(function() {
    var checkresult = checkPhonenum(phoneNum);
    var verificationCode = document.getElementById("verificationCode");
    if (checkresult == true) {
        if (verificationCode.value !== "") {
            var verifyMsg =
                { "code": verificationCode.value,
                  "firmId":"101",
                  "phone": phoneNum.value,
                 // "productType": "1001"
                };
            var verifyUrl = javahost2 + "wx/userEnrollCode";
            //   makeAcall(verifyUrl, verifyMsg);
            $.ajax({
                url: verifyUrl,
                type: "post",
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(verifyMsg),
                success: function(data) {
                    var msg = JSON.parse(data.data)
                    if(data.statusCode == 10010){
                        window.sessionStorage.userId = msg.userId;
                        window.sessionStorage.userCashId = msg.userCashId;
                        window.sessionStorage.merchantid = msg.merchantid;
                        $.router.load("#selectlesson");
                    }

                }
            });
        } else {
            $.alert("请输入正确的验证码哦！", function() {
                verificationCode.focus();
            });
        }
    } else {
        return;
    }
});


//通讯通用类
//构建一个XMLHttpRequest
function getXMLHttpRequest() {
    var xmlHttpReq = false;
    // to create XMLHttpRequest object in non-Microsoft browsers
    if (window.XMLHttpRequest) {
        xmlHttpReq = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        try {
            // to create XMLHttpRequest object in later versions
            // of Internet Explorer
            xmlHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (exp1) {
            try {
                // to create XMLHttpRequest object in older versions
                // of Internet Explorer
                xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (exp2) {
                xmlHttpReq = false;
            }
        }
    }
    return xmlHttpReq;
}
//构建一个XML公有Call并处理结果
function makeAcall(url, datastr) {
    // if (datastr.islastone == "1") {
    //     $.showPreloader('该过程需要几分钟的时间，如退出或重复提交会导致审核失败');
    // } else {
    //     $.showPreloader('请稍候');
    // }
    var XMLHttpRequest = getXMLHttpRequest();
    makeRequest(XMLHttpRequest, url, datastr);
    XMLHttpRequest.onreadystatechange = function() {
        if (XMLHttpRequest.readyState == 4) {
            if (XMLHttpRequest.status == 200) {
                var cdResult = JSON.parse(XMLHttpRequest.responseText);
                if (cdResult.statusCode == 10002) {
                    var databag = JSON.parse(cdResult.data);
                    if (databag.userStatus == "REJECT") {
                        $.alert("该手机号已经被惠学习拒绝过，不能再申请惠学习服务。", function() {
                            window.location.href = "about:blank";
                            window.open("", "_self");
                            window.opener = null;
                            window.close();
                            WeixinJSBridge.call('closeWindow'); //关闭微信浏览器;
                        });
                    } else {
                        $.alert(cdResult.message);
                    }
                } else if (cdResult.statusCode == 10001) {
                    window.sessionStorage.phcdgo = 10001;
                } else if (cdResult.statusCode == 10010) {
                    var databag = JSON.parse(cdResult.data);
                    // window.sessionStorage.authorization = databag.authorization;
                    window.sessionStorage.userId = databag.userId; //USER_ID
                    window.sessionStorage.userCashId = databag.userCashId; //现金贷ID
                    window.sessionStorage.cashStatus = databag.cashStatus; //闪电贷状态
                    window.sessionStorage.cashStatusBit = databag.cashStatusBit; //现金贷状态
                    window.sessionStorage.ruinCashStatus = databag.ruinCashStatus; //及时雨状态
                    window.sessionStorage.raiseCashStatus = databag.raiseCashStatus; //提额状态

                    window.sessionStorage.cashInstallment = databag.cashPeriodizationStatus; //现金分期状态

                    //活动配置
                    if (databag.userActivitys == undefined) {
                        $.alert("没传活动参数，跳过");
                    } else {
                        for(var i=0; i<databag.userActivitys.length; i++){
                            if(databag.userActivitys[i].id==10001){
                                window.sessionStorage.hd10001 = "1";
                                window.sessionStorage.hd10001Auth = databag.userActivitys[i].status;
                            }else if(databag.userActivitys[i].id==10002){
                                window.sessionStorage.hd10002="1";
                                window.sessionStorage.hd10002Auth = databag.userActivitys[i].status;
                            }
                        }
                    }

                    //[
                    //{id:10001,status:1},
                    //{id:10002,status:1}
                    //]
                    //window.sessionStorage.userActivitys = databag.userActivitys;//是否为活动新用户
                    //window.sessionStorage.activityIsOpen = databag.status; //活动是否开启
                    basicPhoneNum.value = phoneNum.value;
                    loginJudge();
                } else if (cdResult.statusCode == 10011) {
                    $.alert(cdResult.message);
                } else if (cdResult.statusCode == 10014) {
                    $.alert(cdResult.message);
                } else if (cdResult.statusCode == 10015) {
                    if (window.sessionStorage.merchantid == "18fd13cc9aa611e6afb66c92bf314c17") {
                        $.router.load("#watingRST");
                    } else {
                        $.router.load("#watingRSTwithoutbigNo");
                    }
                    window.sessionStorage.refreshPD = "flash";
                } else if (cdResult.statusCode == 10016) {
                    $.alert(cdResult.message);
                } else if (cdResult.statusCode == 10017) {
                    if (cdResult.data.userStatus == 7025) {
                        if (window.sessionStorage.merchantid == "18fd13cc9aa611e6afb66c92bf314c17") {
                            if (window.sessionStorage.refreshPD == "timely") {
                            } else {
                            }
                            $.popup('.popup-resultwithbigNotok');
                        } else {
                            if (window.sessionStorage.refreshPD == "timely") {
                            } else {
                            }
                            $.router.load("#watingRSTwithoutbigNonot");
                        }
                    } else if (cdResult.data.userStatus == 7024) {
                        if (window.sessionStorage.merchantid == "18fd13cc9aa611e6afb66c92bf314c17") {
                            $.popup('.popup-resultwithbigOk');
                        } else {
                            $.router.load("#watingRSTwithoutbigNoOk");
                        }
                    } else if (cdResult.data.userStatus == 7023) {

                    } else {

                    }
                } else if (cdResult.statusCode == 1060) {
                    $.alert(cdResult.message);
                } else if (cdResult.statusCode == 10105) {
                    $.alert(cdResult.msg, function() {
                        window.location.href = "about:blank";
                        window.open("", "_self");
                        window.opener = null;
                        window.close();
                        WeixinJSBridge.call('closeWindow'); //关闭微信浏览器;
                    });
                } else {
                    $.alert(cdResult.message);
                }
                $.hidePreloader();
            } else {
                //                  $.alert("HTTP error" + XMLHttpRequest.status + ": " + XMLHttpRequest.statusText);
                $.alert("系统有点忙哦，请稍等片刻");
                $.hidePreloader();
            }
        }
    }
}


//构建一个XML私有Call公有部分
function makeRequest(XMLHttpRequest, url, datastr) {
    XMLHttpRequest.open("POST", url, true);
    XMLHttpRequest.setRequestHeader("Content-Type", "application/json");
    //datastr.authorization = window.sessionStorage.authorization;
    //  datastr.authorization = "201612071709132019850c836a4ac89389b4d2bbbc71b5";
    XMLHttpRequest.send(JSON.stringify(datastr));
}

// ==发送短信验证
function sendCode(thisBtn) {
    thisBtn.setAttribute("disabled", "true");
    thisBtn.style.background = "#bababa";
    thisBtn.style.color = "#fff";
    thisBtn.value = reclickTime + "秒后重获";
    resetButton = setInterval(doLoop, 1000, thisBtn);
}

function doLoop(thisBtn) {
    reclickTime--;
    if (reclickTime > 0) {
        thisBtn.value = reclickTime + "秒后重获";
    } else {
        clearInterval(resetButton);
        thisBtn.disabled = false;
        thisBtn.style.background = "#fe813c";
        thisBtn.style.color = "#fff";
        thisBtn.value = "获取验证码";
        reclickTime = 60;
    }
}



//公用方法：较验手机号有效性
function checkPhonenum(phoneNum) {
    if (phoneNum.value == "") {
        $.alert('请输入正确的手机号哦', function () {
            phoneNum.focus();
        });
        return false;
    } else if (phoneNum.value !== "") {
        var reg0 = /^13\d{5,9}$/;
        var reg1 = /^15\d{5,9}$/;
        var reg2 = /^17\d{5,9}$/;
        //      var reg3 = /^0\d{10,11}$/;
        var reg3 = /^14\d{5,9}$/;
        var reg4 = /^18\d{5,9}$/;
        var my = false;
        if (reg0.test(phoneNum.value)) my = true;
        if (reg1.test(phoneNum.value)) my = true;
        if (reg2.test(phoneNum.value)) my = true;
        //      if (reg3.test(phoneNum.value))my=true;
        if (reg3.test(phoneNum.value)) my = true;
        if (reg4.test(phoneNum.value)) my = true;
        if (!my) {
            $.alert('请输入正确的手机号哦', function () {
                phoneNum.value = "";
                phoneNum.focus();
            });
            return false;
        }
        return true;
    }
}


