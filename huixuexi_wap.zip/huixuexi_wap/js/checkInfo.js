//地区选择器
$(".selectcity").cityPicker({
    toolbarTemplate: '<header class="bar bar-nav">\
    <button class="button button-link pull-right close-picker">确定</button>\
    <h1 class="title">选择地区</h1>\
    </header>'
});
//基本信息提交

$(".msgsubmit").click(function () {
   var msg = $(this).parent().find("input");
   var data = {
       address : msg[0].value.split(" "),
       thoroughAddress : msg[1].value,
       HouseholdRegistration : msg[2].value,
       income : msg[3].value,
       company : msg[4].value,
       companyAddress : msg[5].value.split(" "),
       thoroughCompany : msg[6].value,
       school : msg[7].value,
       schoolTime : msg[8].value
    }
    if(data.address!=='' && data.thoroughAddress!==''&& data.HouseholdRegistration!=="" &&data.income!==''
      &&data.company!==''&&data.companyAddress!==''&&data.thoroughCompany!=="") {
      const userdata = {
        "userId": window.sessionStorage.userId,
        "merchantId": window.sessionStorage.merchantid,
        "quota": 0,
        "annualEarning":data.income,
        "householdAddress" :  data.HouseholdRegistration,//户籍地址
          "productType" : "1001",
          "childSchool" : {
            "title" : data.school,
              "startDate" : data.schoolTime,
          },
        "residentInfo": {
            //居住地址
            "liveAddr": {"province": data.address[0], "city": data.address[1], "district": data.address[2]},
            "specificAddr": data.thoroughAddress,//居住详细地址
        },
          "workInfo" :{
            //工作信息

          "workName": data.company, //公司名称
          //工作地址
          "workAddr": { "province": data.companyAddress[0], "city": data.companyAddress[1], "district": data.companyAddress[2] }, //公司地址
          "specificAddr":data.thoroughCompany,//公司详细地址
        },
    }
        $.ajax({
            url: javahost + "cashloan/submitDetailInfo",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(userdata),
            success: function(data) {
                if(data.statusCode != 200){
                    $.toast(data.message)
                }else{
                    $.toast(data.message)
                    $.router.load("#completedetails");
                }

            }
        });
    }else {
      $.alert('请完善个人信息');
    }

});



  //联系人==亲属关系选择
function relationList(data){
  let stagesList = "";
  for(var i = 0; i<data.length; i++){
    if(data.length===3){
      stagesList += '<li class="list-data close-popup" data-id ='+ data[i].key+ ' onclick="selectRelation($(this))">' +
                      data[i].relation
                    '</li>';
    } else {
      stagesList += '<li class="list-data close-popup" data-id ='+ data[i].key+ ' onclick="selectFriendRelation($(this))">' +
                      data[i].relation
                    '</li>';
    };          
    var content = '<div class="popup popup-order">'+
                    '<h3>与本人关系<img class="close-popup" src="images/popClose@2x.png"></h3>'+
                      '<ul>'+ stagesList +'</ul>'+
                  '</div>';
    $.popup(content);
  }
}
$('#andRelation').click(()=>{
  const data = [
    {key: 2,relation: '父母'},
    {key: 1,relation: '夫妻'},
    {key: 3,relation: '子女'},
  ];
  relationList(data);
})
 //联系人==朋友关系选择
$('#friendsRelation').click(()=>{
  const data = [
    {key: 7,relation: '同学'},
    {key: 6,relation: '朋友'},
    {key: 7,relation: '同事'},
    {key: 4,relation: '其他'},
  ];
  relationList(data);
})
//选择后 页面渲染
function selectRelation(value){
  const selectText = value[0].outerText;
  $('#andRelation').val(selectText);
};
function selectFriendRelation(value){
  const selectText = value[0].outerText;
  $('#friendsRelation').val(selectText);
};
//校验手机号码
function verifyMobile12(str) {
  return /^1[3,4,5,7,8]\d{9}$/.test(str);
}
//姓名有效性校验
function checkRealname12(humanName) {
    var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/
    return regName.test(humanName);

}
//联系人信息验证
function checkRelation(data) {
  if(data.contactInfo[0].relationType==''){
    $.toast('请选择直系亲属关系!');
    return false;
  }
  if(data.contactInfo[0].name==''){
    $.toast('请输入直系亲属名字!');
    return false;
  }
  if(!checkRealname12(data.contactInfo[0].name)){
      $.toast('请输入正确直系亲属名字!');
      return false;
    }

  if(data.contactInfo[0].phone==''){
    $.toast('请输入直系亲属关系电话号码!');
    return false;
  }
  if(!verifyMobile12(data.contactInfo[0].phone)){
      $.toast('请输入正确直系亲属电话号码!');
      return false;
    }

  if(data.contactInfo[1].relationType==''){
    $.toast('请选择朋友关系!');
    return false;
  }
  if(data.contactInfo[1].name==''){
    $.toast('请输入朋友名字!');
    return false;
  }
  if(!checkRealname12(data.contactInfo[1].name)){
      $.toast('请输入正确朋友名字!');
      return false;
    }

  if(data.contactInfo[1].phone==''){
    $.toast('请输入朋友关系电话号码!');
    return false;
  }

  if(!verifyMobile12(data.contactInfo[1].phone)){
      $.toast('请输入正确朋友电话号码!');
      return false;
    }

  return true;
};
//联系人提交
$('#relationSubmit').click(()=>{
  const andRelation = $('#andRelation').val();
  const andRelationName = $('#andRelationName').val();
  const andRelationNum = $('#andRelationNum').val();
  const friendsRelation = $('#friendsRelation').val();
  const friendName = $('#friendName').val();
  const friendNum = $('#friendNum').val();

  var relatives = "";
  var friend = "";

  if(andRelation == "父母"){
      relatives = 2
  }else if(andRelation == "子女"){
      relatives = 3
  }else if(andRelation == "夫妻"){
      relatives = 1
  }

  if(friendsRelation == "同学"){
      friend = 6
  }else if(friendsRelation == "朋友"){
      friend = 6
  }else if(friendsRelation == "同事"){
      friend = 7
  }else if(friendsRelation == "其他"){
      friend = 6
  }


  const data = {
    "userId": window.sessionStorage.userId,
    "productType" : "1001",
    "contactInfo": [{
        "rank" : "1",
        "name" :　andRelationName,
        "relationType":relatives ,
        "phone" :andRelationNum
    },{
        "rank" : "2",
        "name" :　friendName,
        "relationType":friend ,
        "phone" :friendNum
    }]
  }
  if(checkRelation(data)){
      ajax(timelyCfg.api.cashloanSubmitContactInfo, { "data": data }, function(D) {
          if (checkAjaxStart(D)) {
              if(D.statusCode == 200){
                  $.toast(D.message);
                  $.router.load("#completedetails");
              }
          }
      }, function(D) {

      });
  }
})