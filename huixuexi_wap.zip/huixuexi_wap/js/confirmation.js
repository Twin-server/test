
$(".amount").keyup(function () {
    const price = Number($('.price').html());
    const amount = Number($('.amount').val());
    if (amount > price) {
        $('.promptwarning').hide();
        $('.prompterror').show();
    } else {
        $('.promptwarning').show();
        $('.prompterror').hide();
    }
})

$("#VerEffectiveDate").calendar({
    value: ["2017-01-01 "]
});

$("#schooltime").calendar({
    value: ["2017-01-01 "]
});

//选取分期数额，页面添加详情
  // 点击分期,选择期数
function selectStages(value) {
  const val = value.children()[1].innerHTML;
  $('#staging').val(val);
  $('.details').show();
  $('#everPrice').text(val);
}
// 分期详情
$(document).on('click', '.details', function() {
  const data = [
    {
      stages: '第一期',
      principal: 310,
      interest: 10,
    },
    {
      stages: '第一期',
      principal: 103,
      interest: 10,
    },
    {
      stages: '第一期',
      principal: 10,
      interest: 210,
    },
    {
      stages: '第一期',
      principal: 10,
      interest: 210,
    },
    {
      stages: '第一期',
      principal: 10,
      interest: 210,
    },
    {
      stages: '第一期',
      principal: 10,
      interest: 210,
    },
    {
      stages: '第一期',
      principal: 10,
      interest: 210,
    },
    {
      stages: '第一期',
      principal: 10,
      interest: 210,
    },
    {
      stages: '第一期',
      principal: 10,
      interest: 210,
    },
  ];
  let htmlCont = "";
  for(var i = 0; i<data.length; i++){
    htmlCont += '<li class="detailsData">' +
                  '<span>'+ data[i].stages+'</span>'+
                  '<span>'+ data[i].principal+'</span>'+
                  '<span>'+ data[i].interest+'</span>'+
                '</li>';
  }
  $.modal({
    title: '<div class="detailsDialog">'+
              '<h3>分期详情<img class="closeDialog close-popup" src="images/popClose@2x.png"></h3>'+
              '<div>'+
                  '<h5>总本金:￥45000 + 总手续费:￥3000</h5>'+
              '</div>'+
          '</div>',
    text: '<div class="dataList content-block">'+
            '<div class="header">' +
                '<span>期数</span>'+
                '<span>本金</span>'+
                '<span>手续费</span>'+
              '</div>'+
              '<ul>'+ htmlCont +'</ul>'+
            '</div>',
  })
  $(document).on('click', '.closeDialog', function() {
    $.closeModal('.modal');
  });
});

//获取利率
$(document).on("pageInit", function(e, pageId, $page) {

    if (pageId == "confirmation") {
        if(window.sessionStorage.classId == "" ||  window.sessionStorage.classPrice == ""){
            $.alert("请选择课程",function () {
                $.router.load("#selectlesson");
            })
            return;
        }
        $(".price").html(window.sessionStorage.classPrice);
        var data = {
            "coursewareId" : window.sessionStorage.classId
        };

        $.ajax({
            url: javahost4 + "hxx/getCourseStagesList",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),
            success: function(data) {
                console.log(data);
                // 点击分期,popUp显示
                $('#staging').click(()=>{
                    let stagesList = "";
                    for(var i = 0; i<data.data.stagesList.length; i++){
                        stagesList += '<li class="list-data close-popup" onclick="selectStages($(this))">' +
                            '<h4>'+ data.data.stagesList[i].loanRate+'</h4>'+
                            '<p>'+ data.data.stagesList[i].stagesCount+'</p>'+
                            '</li>';
                    };
                    var content = '<div class="popup popup-order">'+
                        '<h3>选择期数<img class="close-popup" src="images/popClose@2x.png"></h3>'+
                        '<ul>'+ stagesList +'</ul>'+
                        '</div>';
                    $.popup(content);
                });
            }
        });
    }
});


