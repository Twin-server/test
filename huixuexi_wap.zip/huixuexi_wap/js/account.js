/*
* @Author: jeff
* @Date:   2017-07-17 10:53:34
* @Last Modified by:   jeff
* @Last Modified time: 2017-07-20 19:42:33
*/

'use strict';
$(function(){
	$.init();
	// $.router.load("#billList");
	//
	showPay();
});


//支付方式弹窗
function showPay(item){
	var modal = $.modal({
		extraClass:'pay-modal',
		title:'<div class="modal-head"><div>选择支付方式</div><div class="icon-close"></div></div>'+
			  '<ul class="pay-list">\
					<li class="current"><div class="icon-wx"></div><div class="pay-name">微信支付</div><div class="input-check"><input type="checkbox" value="wx"></div></li>\
					<li class="pay-line"></li>\
					<li><div class="icon-kj"></div><div class="pay-name">快捷支付</div><div class="input-check"><input type="checkbox" value="kj"></div></li>\
			  </ul>\
			  <ul class="pay-mate">\
			  		<li><div>还款金额</div><div>9000.00元</div></li>\
			  		<li><div>本金</div><div>9000.00元</div></li>\
			  		<li><div>利息</div><div>0.00元</div></li>\
			  		<li><div>提前结清手续费</div><div>10.00元</div></li>\
			  </ul>\
			  <button type="button" class="btn2 mg2">立即支付9000.00元</button>\
			  '

	});
}
