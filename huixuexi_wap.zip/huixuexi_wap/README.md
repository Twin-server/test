# huixuexi_wap

框架API地址：http://m.sui.taobao.org/


环境开发
1.安装cnpm

2.进入项目文件夹安装模块
cnpm i -g gulp
cnpm i -g browser-sync
cnpm i

3.启动项目
npm start

4.监听less
npm run w 监听