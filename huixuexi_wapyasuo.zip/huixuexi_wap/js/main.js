/**
 * Created by Administrator on 2017/7/24.
 */

$(function () {
    if (window.sessionStorage.userId == "") {
      //   $.router.load("#login");
        //13bc970f84e84e6aa24d60d944f5b5ef
    }

    window.name = "test";
    window.sessionStorage.userId = ""; //USER_ID
    window.sessionStorage.userCashId = "";
    window.sessionStorage.courseOrderId = ""; //订单号

    window.sessionStorage.merchantid = "";
    window.sessionStorage.selectproduct = "";
    window.sessionStorage.isquota = "";
    window.sessionStorage.refreshPD = "";
    window.sessionStorage.authorization = "";
    window.sessionStorage.hdId = "";

    window.sessionStorage.Identity = "";//身份
    window.sessionStorage.classId = "";
    window.sessionStorage.classPrice = "";
    window.addEventListener('message',function(e){
        if (typeof (e.data) =='string')  {
            if(e.data.indexOf("?params=") != -1 ){
                checksesameresult (e.data);
            }
        }
    },false);



    $.init();
})

var checkStart = {
    identityCard: "",
    mobileVerify: "",
    otherLinkman: "",
    userMoreVerify: "",
    userSesameF: ""
}

//interface
var javahost = "http://118.190.67.197:8070/v2/"; //开发URL
var javahostv3 = "http://118.190.67.197:8070/v3/"; //开发URL
var javahost2 = "http://118.190.67.197:8030/"; //开发URL

var javahost4 = "http://118.190.67.197:8080/"; //开发URL


 // var javahost = "http://118.190.60.163:8070/v2/"; //预发布URL
 // var javahostv3 = "http://118.190.60.163:8070/v3/"; //预发布URL
 // var javahost2 = "http://118.190.60.163:8030/"; //预发布URL



// var javahost = "https://api.credan.com/v2/"; //正式
// var javahostv3 = "https://api.credan.com/v3/"; //正式
// var javahost2 = "https://consumer.credan.com/";

// var javahost = "http://192.168.1.100:8080/"; //预发布URL
// var javahostv3 = "http://192.168.1.100:8080/"; //预发布URL
// var javahost2 = "http://192.168.1.100:8080/"; //预发布URL

var timelyCfg = {
    api: {
        cashloantestMessage: javahost + 'cashloan/submitOrderInfo',
        cashloanQueryUserInfo: javahost + 'cashloan/queryUserInfo',
        cashloanSubmitUserInfo: javahost + 'cashloan/submitUserInfo',
        cashloanSubmitContactInfo: javahost + 'cashloan/submitContactInfo',
        cashloanSubmitDetailInfo: javahost + 'cashloan/submitDetailInfo',
        cashloanFinalSubmit: javahost + 'cashloan/finalSubmit',
        collectionMobileSubmit: javahost + "user/collection/mobile/submit",
        userFileUploadByUserId: javahost + "user/file/uploadByUserId",
        userFileShowImg: javahost + 'user/file/showImg'
    }
}

var reclickTime =60;

//发起call类
//CALL接口获取验证码并在60秒内不可再次点击
var handlerPopup = function(captchaObj) {
    captchaObj.onReady(function() {
        captchaObj.show();
    });
    // 成功的回调
    captchaObj.onSuccess(function() {
        var validate = captchaObj.getValidate();
        $.ajax({
            url: javahost2 + "wx/enrollSendCode", // 进行二次验证
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                phone: $('#phoneNum').val(),
                geetest_challenge: validate.geetest_challenge,
                geetest_validate: validate.geetest_validate,
                geetest_seccode: validate.geetest_seccode
            }),
            success: function(data) {
                if (data.statusCode == 10001) {
                    window.sessionStorage.phcdgo = 10001;
                    $.toast("发送成功！");
                } else {
                    $.alert(data.message);
                }

            }
        });
    });
    // 将验证码加到id为captcha的元素里
    captchaObj.appendTo("#popup-captcha");
    // 更多接口参考：http://www.geetest.com/install/sections/idx-client-sdk.html
};


var phoneNum = document.getElementById("phoneNum");
$("#getPhcodebtn").click(function() {
    var checkresult = checkPhonenum(phoneNum);
    if (checkresult == true) {
        sendCode(this);
        // 验证开始需要向网站主后台获取id，challenge，success（是否启用failback）
        $.ajax({
            url: javahost2 + "wx/smsCaptcha",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                phone: $('#phoneNum').val(),
            }),
            success: function(data) {
                // 使用initGeetest接口
                // 参数1：配置参数
                // 参数2：回调，回调的第一个参数验证码对象，之后可以使用它做appendTo之类的事件
                initGeetest({
                    gt: data.gt,
                    https: true,
                    challenge: data.challenge,
                    product: "popup", // 产品形式，包括：float，embed，popup。注意只对PC版验证码有效
                    offline: !data.success // 表示用户后台检测极验服务器是否宕机，一般不需要关注
                    // 更多配置参数请参见：http://www.geetest.com/install/sections/idx-client-sdk.html#config
                }, handlerPopup);
            }
        });
    } else {

    }
});

// ===注册
$("#regandloginbtn").click(function() {
    var checkresult = checkPhonenum(phoneNum);
    var verificationCode = document.getElementById("verificationCode");
    if (checkresult == true) {
        if (verificationCode.value !== "") {
            var verifyMsg =
                { "code": verificationCode.value,
                    "firmId":"101",
                    "phone": phoneNum.value,
                    // "productType": "1001"
                };
            var verifyUrl = javahost2 + "wx/userEnrollCode";
            //   makeAcall(verifyUrl, verifyMsg);
            $.ajax({
                url: verifyUrl,
                type: "post",
                dataType: "json",
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(verifyMsg),
                success: function(data) {
                    var msg = JSON.parse(data.data)
                    if(data.statusCode == 10010){
                        window.sessionStorage.userId = msg.userId;
                        window.sessionStorage.userCashId = msg.userCashId;
                        window.sessionStorage.merchantid = msg.merchantid;
                        $.router.load("#selectlesson");
                    }

                }
            });
        } else {
            $.alert("请输入正确的验证码哦！", function() {
                verificationCode.focus();
            });
        }
    } else {
        return;
    }
});

//通讯通用类
//构建一个XMLHttpRequest
function getXMLHttpRequest() {
    var xmlHttpReq = false;
    // to create XMLHttpRequest object in non-Microsoft browsers
    if (window.XMLHttpRequest) {
        xmlHttpReq = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        try {
            // to create XMLHttpRequest object in later versions
            // of Internet Explorer
            xmlHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (exp1) {
            try {
                // to create XMLHttpRequest object in older versions
                // of Internet Explorer
                xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (exp2) {
                xmlHttpReq = false;
            }
        }
    }
    return xmlHttpReq;
}


//构建一个XML私有Call公有部分
function makeRequest(XMLHttpRequest, url, datastr) {
    XMLHttpRequest.open("POST", url, true);
    XMLHttpRequest.setRequestHeader("Content-Type", "application/json");
    //datastr.authorization = window.sessionStorage.authorization;
    //  datastr.authorization = "201612071709132019850c836a4ac89389b4d2bbbc71b5";
    XMLHttpRequest.send(JSON.stringify(datastr));
}

// ==发送短信验证
function sendCode(thisBtn) {
    thisBtn.setAttribute("disabled", "true");
    thisBtn.style.background = "#bababa";
    thisBtn.style.color = "#fff";
    thisBtn.value = reclickTime + "秒后重获";
    resetButton = setInterval(doLoop, 1000, thisBtn);
}

function doLoop(thisBtn) {
    reclickTime--;
    if (reclickTime > 0) {
        thisBtn.value = reclickTime + "秒后重获";
    } else {
        clearInterval(resetButton);
        thisBtn.disabled = false;
        thisBtn.style.background = "#fe813c";
        thisBtn.style.color = "#fff";
        thisBtn.value = "获取验证码";
        reclickTime = 60;
    }
}

//公用方法：较验手机号有效性
function checkPhonenum(phoneNum) {
    if (phoneNum.value == "") {
        $.alert('请输入正确的手机号哦', function () {
            phoneNum.focus();
        });
        return false;
    } else if (phoneNum.value !== "") {
        var reg0 = /^13\d{5,9}$/;
        var reg1 = /^15\d{5,9}$/;
        var reg2 = /^17\d{5,9}$/;
        //      var reg3 = /^0\d{10,11}$/;
        var reg3 = /^14\d{5,9}$/;
        var reg4 = /^18\d{5,9}$/;
        var my = false;
        if (reg0.test(phoneNum.value)) my = true;
        if (reg1.test(phoneNum.value)) my = true;
        if (reg2.test(phoneNum.value)) my = true;
        //      if (reg3.test(phoneNum.value))my=true;
        if (reg3.test(phoneNum.value)) my = true;
        if (reg4.test(phoneNum.value)) my = true;
        if (!my) {
            $.alert('请输入正确的手机号哦', function () {
                phoneNum.value = "";
                phoneNum.focus();
            });
            return false;
        }
        return true;
    }
}


//加载课程列表
$(document).on("pageInit", function(e, pageId, $page) {
    if(pageId == "selectlesson") {
        var url = window.location.href;
        var urlQuery = getQueryObject(url);
        $.ajax({
            type: "post",
            url: javahost4 + "hxx/getCoursewareList",
            data: JSON.stringify({"eduId":"1"}),
            datatype: "json",
            contentType: "application/json;charset=utf-8",
            success: function (data) {
                $("#storeName").html(data.data.eduAddress);
                $("#storeAdd").html(data.data.eduName);
                for (var i = 0; i < data.data.coursewareList.length; i++) {
                    $(".lessonlists").append('<li class="lessonitem blk w100 bddfd"><dl class="blk"><dt class="ft32 col202 crude">' + data.data.coursewareList[i].coursewareName + '</dt><dd class="blk flexbetween mgt10"><div class="w40"><p class="ft48 crude colff6">' + data.data.coursewareList[i].coursewarePrice + '</p><!--<p class="ft26  col808">课程价格</p>--!></div><div class="w30"><p class="ft48 crude col4a4">' + data.data.coursewareList[i].stagesCount + '<span class="ft30 pdl10">期</span></p><p class="ft26 col808">可分期数</p></div><a class="signupbtn w30 ft26 mgt34" external data-price="' + data.data.coursewareList[i].coursewarePrice + '" data-id="' + data.data.coursewareList[i].coursewareId + '">立即分期</a></dd></dl></li>');
                }
            },
            error: function () {
                console.log("请求资源出错了");
            }
        });
    }
});


// 点击申请贷款
$('#application').click(function () {
    const price = $('.price').html();
    const amount = $('.amount').val();
    const stages = $('#staging').val();
    const radio = $("input[name='identity']:checked");

    if(amount == ''){
        $.toast('请输入贷款金额!');
    }else if(Number(amount)>Number(price)){
        $.toast('贷款金额大于课程金额!');
    }else if(stages=='') {
        $.toast('请选择分期数!');
    } else {
        $.ajax({
            url: javahost4 + "hxx/createCoursewareOrder",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                "coursewareId" : window.sessionStorage.classId,
                "identityInfo" : radio.data("identity"),
                "loanAmount" : amount,
                "stagesCount" : stages,
                "turnoverAmount" : price,
                "userId" : window.sessionStorage.userId,
            }),
            success: function(data) {
                if(data.status != 200){
                    $.alert(data.message)
                }else{
                    window.sessionStorage.Identity = radio.val();
                    window.sessionStorage.courseOrderId = data.data.courseOrderId;
                    $.router.load("#completedetails");
                }


            }
        });

    }
})

/*用户信息填写情况预查询*/
$(document).on("pageInit", function(e, pageId, $page) {
    if (pageId == "completedetails") {
        var data = {
            "cashId": window.sessionStorage.userCashId,
            "userId": window.sessionStorage.userId,
            "merchantId": window.sessionStorage.merchantid,
            "type": 0,
            "productType": 1001
        };
        ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": data }, function(D) {
            if (checkAjaxStart(D)) {
                userInfoInit(D);
            }
        });

        var phonedata = {
            "cashId": window.sessionStorage.userCashId,
            "userId": window.sessionStorage.userId,
            "merchantId": window.sessionStorage.merchantid,
            "type": 2,
            "productType": 1001
        };
        ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": phonedata }, function(D) {
            if (checkAjaxStart(D)) {
                $(".isVerified .crude").html(D.data.phone)
            }
        });
    }
});

window.sessionStorage.HANDHELD_ID = 0;
window.sessionStorage.IDCARD_FACADE = 0;
window.sessionStorage.IDACRD_REVERSE = 0;


//身份验证弹窗
$(".isVerified").click(function() {
    var data = {
        "cashId": window.sessionStorage.userCashId,
        "userId": window.sessionStorage.userId,
        "merchantId": window.sessionStorage.merchantid,
        "type": 1,
        "productType": 1001
    };
    ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": data }, function(D) {
        if (checkAjaxStart(D)) {
            $.router.load("#verification1");
            var formItem = $(".usermsg").find("input");
            formItem.eq(0).val(D.data.name);
            formItem.eq(1).val(D.data.idNum);
            formItem.eq(2).val(D.data.idNum);
            formItem.eq(3).val(D.data.bankCard);

        }
    });

    window.sessionStorage.HANDHELD_ID = 0;
    window.sessionStorage.IDCARD_FACADE = 0;
    window.sessionStorage.IDACRD_REVERSE = 0;
    ajax(timelyCfg.api.userFileShowImg, { "data": { "userId": window.sessionStorage.userId } }, function(D) {
        if (checkAjaxStart(D)) {
            if (D.data.filePath.HANDHELD_ID != "") {
                if ($("#frontimg").length >= 1) frontimg.src = D.data.filePath.HANDHELD_ID;
                window.sessionStorage.HANDHELD_ID = 1;
            } else {
                window.sessionStorage.HANDHELD_ID = 0;
            }
            if (D.data.filePath.IDCARD_FACADE != "") {
                if ($("#positivesPic").length >= 1) positivesPic.src = D.data.filePath.IDCARD_FACADE;
                window.sessionStorage.IDCARD_FACADE = 1;
            } else {
                window.sessionStorage.IDCARD_FACADE = 0;
            }
            if (D.data.filePath.IDACRD_REVERSE != "") {
                if ($("#reversesPic").length >= 1) reversesPic.src = D.data.filePath.IDACRD_REVERSE;
                window.sessionStorage.IDACRD_REVERSE = 1;
            } else {
                window.sessionStorage.IDACRD_REVERSE = 0;
            }

        }
    });

});
//基本信息
$(".basicInformation").click(function() {
    // if (!checkStart.identityCard) {
    //     $.alert("请先完善身份验证内的信息哦！");
    //     return false;
    // }

    var data = {
        "cashId": window.sessionStorage.userCashId,
        "userId": window.sessionStorage.userId,
        "merchantId": window.sessionStorage.merchantid,
        "type": 4,
        "productType": 1001
    };
    ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": data }, function(D) {
        if (checkAjaxStart(D)) {
                 $.router.load("#verification2-work");
           var address = D.data.residentInfo.liveAddr;
           var workAddr = D.data.workInfo.workAddr;

            var msg = $("#verification2-work").find("input");
            msg[0].value = address.province + " " + address.city + " " + address.district;
            msg[1].value = D.data.residentInfo.specificAddr;
            msg[2].value = D.data.houseHoldAddress;
            msg[3].value = D.data.annualEarning;
            msg[4].value = D.data.workInfo.workName;
            msg[5].value = workAddr.province + " " + workAddr.city + " " + workAddr.district;
            msg[6].value = D.data.workInfo.specificAddr;
        }
    });
});
//紧急联系人
$("#contactPerson").click(function() {
    // if (!_that.checkStart.identityCard) {
    //     $.alert("请先完善身份验证内的信息哦！");
    //     return false;
    // }s

    var data = {  //window.sessionStorage.userId,
        "cashId": window.sessionStorage.userCashId,
        "userId": window.sessionStorage.userId,
        "merchantId": window.sessionStorage.merchantid,
        "type": 3,
        "productType": 1001
    };
    ajax(timelyCfg.api.cashloanQueryUserInfo, { "data": data }, function(D) {
        if (checkAjaxStart(D)) {
            $.router.load("#verification3");
            if (D.data.contact) {
                var everArr = D.data.contact;

                var relationship = "";
                var relationship2 = "";
                if(everArr[0].relationType == 1){
                    relationship = "夫妻"
                }else if(everArr[0].relationType == 2){
                    relationship = "父母"
                }else if(everArr[0].relationType == 3){
                    relationship = "子女"
                }

                if(everArr[1].relationType == 6){
                    relationship2 = "其他"
                }else if(everArr[1].relationType == 7){
                    relationship2 = "同事"
                }

                $("#andRelation").val(relationship);
                $("#andRelationName").val(everArr[0].name)
                $("#andRelationNum").val(everArr[0].phone)

                $("#friendsRelation").val(relationship2)
                $("#friendName").val(everArr[1].name)
                $("#friendNum").val(everArr[1].phone)


            }
        }
    });
});

//芝麻分授权
$("#userSesameFraction").click(function () {
    // if (!_that.checkStart.identityCard) {
    //     $.alert("请先完善身份验证内的信息哦！");
    //     return false;
    // }
    $.showPreloader();
    var data = {
        "userId": window.sessionStorage.userId
    };
    $.ajax({
        type: "post",
        url: javahostv3 + "collect/zhima/authorize/" + window.sessionStorage.userId,
        data: data,
        datatype: "json",
        contentType: "application/json;charset=utf-8",
        success: function(data) {
            $.hidePreloader(); //显示蒙版层
            if (data.success) {
                var ah5url = data.data;
                $.popup('.popup-user-sesame');
                if (sesameiframe.location.href) {
                    sesameiframe.location.href = ah5url;
                } else {
                    sesameiframe.src = ah5url;
                }
            } else {
                $.alert(data.message);
            }
        },
        //请求出错处理
        error: function() {
            $.hidePreloader(); //显示蒙版层
            $.alert("服务器繁忙");
        }
    })
})

function checksesameresult (data) {
    $.showPreloader();
    var x = data.indexOf("?params=");
    var y = data.indexOf("&sign=");
    var hfstr1 = data.substring(x + 8, y);
    var hfstr2 = data.substring(y + 6);
    $.ajax({
        type: "post",
        url: javahostv3 + "collect/zhima/getOpenId/" + hfstr1 + "/" + hfstr2 ,
        data: data,
        datatype: "json",
        contentType: "application/json;charset=utf-8",
        success: function(data) {
            $.hidePreloader(); //显示蒙版层
            if (data.success) {
                $.alert("芝麻分授权成功！" , function () {
                    $.closeModal('.popup-user-sesame');
                    $(userSesameFraction).find(".icon-f5").addClass("icon-f5-pass");
                    $(userSesameFraction).find(".item-after").addClass("fc1").html("已验证");
                    checkStart.userSesameFra = true;
                });
            } else {
                $.alert(data.message , function (){
                    $.closeModal('.popup-user-sesame');
                });
            }
        },
        //请求出错处理
        error: function() {
            $.hidePreloader(); //显示蒙版层
            $.alert("服务器繁忙");
        }
    })
}

function userInfoInit(D) {
   checkStart = {
        identityCard: D.data.identity,    //身份证
        userMoreVerify: D.data.more,     //更多信息
        otherLinkman: D.data.contact  ,  //联系人
        userSesameF: D.data.zhima        //芝麻分
    }
    userInfoPageShow();
}

function userInfoPageShow() {

    if (checkStart.identityCard) {
        var obj = $(".isVerified");
        obj.find(".whetherIdentity").addClass("littlebtnadd").html("身份证已传");
        obj.find(".whetherName").addClass("littlebtnadd").html("已验证");
    }
    if (checkStart.userMoreVerify) {
        obj = $(".basicInformation");
        obj.find(".whetherInformation").addClass("littlebtnadd").html("已验证");
    }
    if (checkStart.otherLinkman) {
        obj = $(".emergency");
        obj.find(".whetherEmergency").addClass("littlebtnadd").html("已验证");
    }
    if (checkStart.userSesameF) {
        obj = $("#userSesameFraction");
        obj.find(".whetherAuth").addClass("littlebtnadd").html("已授权");
    }

}

$(".signupbtn").live("click", function () {
    var lessonId = $(this).data("id");
    var classprice =  $(this).data("price");
    window.sessionStorage.classId = lessonId;
    window.sessionStorage.classPrice = classprice;
    $.ajax({
        url: "js/test.json",
        type: "GET",
        data: {lessonId: lessonId},
        dataType: "json",
        success: function (data) {
            $.router.load("#confirmation");
        },
        error: function () {
            console.log("请求课程信息出错");
        }
    });
});

//上传手持身份证
$("#frontimg").live("click",function () {
    console.log("上传手持身份证");
    $("#clicktoupload").click();
})
//上传身份证正面
$("#positivesPic").live("click",function () {
    console.log("上传身份证正面");
    $("#positiveupload").click();
})
//上传身份证反面
$("#reversesPic").live("click",function () {
    console.log("上传身份证反面");
    $("#reverseupload").click();
})

//身份证信息获取
var input1 = document.querySelector('#clicktoupload');
var input2 = document.querySelector('#positiveupload');
var input3 = document.querySelector('#reverseupload');

function getCardMsg() {

    if(($("#reportholdidcard li").length == 2) && ($("#positiveBox li").length == 2)){
        $.ajax({
            url: javahost + "user/file/uploadByUserId",
            type: "POST",
            data: JSON.stringify(upLdfrontMsg),
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            success: function (data) {
                var formItem = $(".usermsg").find("input");
                    formItem.eq(0).val(data.name), //姓名
                    formItem.eq(1).val(data.citizenId), //身份证号
                    formItem.eq(2).val(data.validDateEnd)  //证件有效日
            },
            error: function () {
                console.log("请求身份证信息出错");
            }
        });
    }

}

var upLdfrontMsg = {
    "userId": window.sessionStorage.userId,
    "productType" : "1001",
    "ocr" : "1",
    "HANDHELD_ID": {
        facade: 8,
        filename: '1.jpg',
        file: ""
    },
    "IDCARD_FACADE": {
        facade: 1,
        filename: '2.jpg',
        file: ""
    },
    "IDACRD_REVERSE": {
        facade: 2,
        filename: '3.jpg',
        file: ""
    },

};

function clicktouploadchange() {

    if ($("#reportholdidcard li").length == 2) {
        var imgbssixfour1 = frontimg.src;
        imgbssixfour1 = imgbssixfour1.slice(23, imgbssixfour1.length);
        upLdfrontMsg.HANDHELD_ID.file = imgbssixfour1;
    }
}
function positiveuploadchange() {

    if ($("#positiveBox li").length == 2) {
        var imgbssixfour2 = positivesPic.src;
        imgbssixfour2 = imgbssixfour2.slice(23, imgbssixfour2.length);
        upLdfrontMsg.IDCARD_FACADE.file = imgbssixfour2;
    }
}
function reverseuploadchange() {

    if ($("#reverseBox li").length == 2) {
        var imgbssixfour3 = reversesPic.src;
        imgbssixfour3 = imgbssixfour3.slice(23, imgbssixfour3.length);
        upLdfrontMsg.IDACRD_REVERSE.file = imgbssixfour3;
    }
}


input1.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {

            var imgbssixfour1 = holdidcard_report(' ', results.base64, results.base64.length,"#reportholdidcard","frontimg");
            imgbssixfour1 = imgbssixfour1.slice(23, imgbssixfour1.length);
            upLdfrontMsg.HANDHELD_ID.file = imgbssixfour1;
            getCardMsg();
        }
    });

};

input2.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {

            var imgbssixfour2 =holdidcard_report(' ', results.base64, results.base64.length,"#positiveBox","positivesPic");
            imgbssixfour2 = imgbssixfour2.slice(23, imgbssixfour2.length);
            upLdfrontMsg.IDCARD_FACADE.file = imgbssixfour2;
            getCardMsg();
        }
    });


};

input3.onchange = function () {
    lrz(this.files[0], {width: 640}, function (results) {
        // 你需要的数据都在这里，可以以字符串的形式传送base64给服务端转存为图片。
        //console.log(results);
        if (results.base64.length > 819200) {
            $.alert("您上传的图片过大，请自行裁切后再继续上传。");
        } else {
           // holdidcard_report(' ', results.base64, results.base64.length,"#reverseBox","reversesPic");
            var imgbssixfour3 =  holdidcard_report(' ', results.base64, results.base64.length,"#reverseBox","reversesPic");
            imgbssixfour3 = imgbssixfour3.slice(23, imgbssixfour3.length);
            upLdfrontMsg.IDACRD_REVERSE.file = imgbssixfour3;
            getCardMsg();
        }
    });

};

function holdidcard_report(title, src, size,id1,id2) {
    var img = new Image(),
        li = document.createElement('div'),
        size = (size / 1024).toFixed(2) + 'KB';
    img.onload = function () {
        var content = '<ul style="display:none">' +
            '<li>' + title + '（' + img.width + ' X ' + img.height + '）</li>' +
            '<li class="text-cyan">' + size + '</li>' +
            '</ul>';
        li.className = 'item';
        li.innerHTML = content;
        li.appendChild(img);
        $(id1).html('');
        document.querySelector(id1).appendChild(li);

    };
    img.setAttribute("id", id2);
    if(id1=="#reportholdidcard"){
        img.className="photo";
    }else{
        img.className="photo2";
    }

    img.src = src;
    return src;

}


//身份证信息获取结束///////////////////////////////////
$("#VerSubmit").click(function () {

    if (window.sessionStorage.HANDHELD_ID == "0") {
        if ($("#reportholdidcard li").length <= 0) {
            $.alert("请上传手持身份证照片哦！");
           // disabled(VerSubmit);
            return false;
        }
    }
    if (window.sessionStorage.IDCARD_FACADE == "0") {
        if ($("#positiveBox li").length <= 0) {
            $.alert("请上传身份证正面照片哦！");
            //disabled(VerSubmit);
            return false;
        }
    }
    if (window.sessionStorage.IDACRD_REVERSE == "0") {
        if ($("#reverseBox li").length <= 0) {
            $.alert("请上传身份证反面照片哦！");
           // disabled(VerSubmit);
            return false;
        }
    }

    var formItem = $(".usermsg").find("input");
    var msgdata = {  //window.sessionStorage.userId
        "productType": "1001",
        "merchantId": window.sessionStorage.merchantid,
        "userId" : "13bc970f84e84e6aa24d60d944f5b5ef",
        "name": formItem.eq(0).val(), //姓名
        "idNum": formItem.eq(1).val(), //身份证号
        "idNumValidDateEnd": formItem.eq(2).val(), //证件有效日期
        "cardNum": formItem.eq(3).val() //银行卡号
    }

    //表单验证
    var msgistrue = checkUserCard(formItem, msgdata);
    if(msgistrue){
        $.ajax({
            url: javahost + "cashloan/submitUserInfo",
            type: "POST",
            data: JSON.stringify(msgdata),
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            success: function (data) {
                //  $.router.load("#login");
            },
            error: function () {
                console.log("请求身份证信息出错");
            }
        });
    }
    
});

//提交订单
$(".submitbtnadd").click(function () {
    var data = {
        "courseOrderId" : window.sessionStorage.courseOrderId,
        "userId" : 　window.sessionStorage.userId
    }


    if (checkStart.identityCard && checkStart.userMoreVerify &&
        checkStart.otherLinkman && checkStart.userSesameF) {
        $.ajax({
            url: javahost4 + "hxx/submitCourseOrder",
            type: "POST",
            data: JSON.stringify(data),
            dataType: "json",
            contentType: "application/json;charset=utf-8",
            success: function (data) {
                if(data.status == 200){
                    $.router.load("#submitted");
                }else {
                    $.toast(data.message);
                }

            },
            error: function () {

            }
        });
    }else{
        $.alert("请完善信息后提交!!!");
    }



})

function checkAjaxStart(D) {
    if (D.success == true) {
        return true;
    } else {
        $.alert(D.message);
        return false;
    }
}

//获取URL参数
function getQueryObject(url) {
    url = url == null ? window.location.href : url;
    var search = url.substring(url.lastIndexOf("?") + 1);
    var obj = {};
    var reg = /([^?&=]+)=([^?&=]*)/g;
    search.replace(reg, function (rs, $1, $2) {
        var name = decodeURIComponent($1);
        var val = decodeURIComponent($2);
        val = String(val);
        obj[name] = val;
        return rs;
    });
    return obj;
}


//数字千位格式化  3,000,000
function toThousands(num) {
    var result = [ ], counter = 0;
    num = (num || 0).toString().split('');
    for (var i = num.length - 1; i >= 0; i--) {
        counter++;
        result.unshift(num[i]);
        if (!(counter % 3) && i != 0) { result.unshift(','); }
    }
    return result.join('');
}

// --------验证类方法-------


function checkUserCard(formItem, data) {
    //姓名
    if (data.name == "") {
        $.alert(msg.userName.empty, function() {
            formItem.eq(0).focus();
        });
        return false;
    }

    if (!this.checkRealname2(data.name)) {
        $.alert(msg.userName.error, function() {
            formItem.eq(0).focus();
        });
        return false;
    }
    //身份证号
    if (data.idNum == "") {
        $.alert(msg.idNum.empty, function() {
            formItem.eq(1).focus();
        });
        return false;
    }
    if (!this.checkIdcard2(data.idNum)) {
        $.alert(msg.idNum.error, function() {
            formItem.eq(1).focus();
        });
        return false;
    }
    //身份证有效日期
    if (data.idNumValidDateEnd == "") {
        $.alert(msg.idData.empty, function() {
            formItem.eq(2).focus();
        });
        return false;
    }
    //银行卡号
    if (data.cardNum == "") {
        $.alert(msg.cardNum.empty, function() {
            formItem.eq(3).focus();
        });
        return false;
    }
    if (!this.checkBanknumber2(data.cardNum)) {
        $.alert(msg.cardNum.error, function() {
            formItem.eq(3).focus();
        });
        return false;
    }

    return true;
};





//真实姓名有效性校验
function checkRealname(humanName) {
    if (humanName.value == "") {
        $.alert('请输入正确的真实姓名哦', function() {
            humanName.focus();
        });
    } else {
        var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/;
        if (regName.test(humanName.value) !== true) {
            return false;
        } else {
            return true;
        }
    }
};
//姓名有效性校验
function checkRealname2(humanName) {
    var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/
    return regName.test(humanName);
};


//严格身份证号码校验
function checkIdcard2(humanId) {
    humanId = humanId.replace('x', 'X');
    var vcity = {
        11: "北京",
        12: "天津",
        13: "河北",
        14: "山西",
        15: "内蒙古",
        21: "辽宁",
        22: "吉林",
        23: "黑龙江",
        31: "上海",
        32: "江苏",
        33: "浙江",
        34: "安徽",
        35: "福建",
        36: "江西",
        37: "山东",
        41: "河南",
        42: "湖北",
        43: "湖南",
        44: "广东",
        45: "广西",
        46: "海南",
        50: "重庆",
        51: "四川",
        52: "贵州",
        53: "云南",
        54: "西藏",
        61: "陕西",
        62: "甘肃",
        63: "青海",
        64: "宁夏",
        65: "新疆",
        71: "台湾",
        81: "香港",
        82: "澳门",
        91: "国外"
    };
    var regId = /(^\d{17}(\d|X)$)/;
    var province = humanId.substr(0, 2);
    var len = humanId.length;
    var re_eighteen = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/;
    var arr_data = humanId.match(re_eighteen);
    if (regId.test(humanId) == false) {
        return false; //校验位数；
    } else if (vcity[province] == undefined) {
        return false; //校验城市
    } else if (regId.test(humanId) !== false) {
        var year = arr_data[2];
        var month = arr_data[3];
        var day = arr_data[4];
        var birthday = new Date(year + '/' + month + '/' + day);
        var now = new Date();
        var now_year = now.getFullYear();
        var time = now_year - year;
        if (birthday.getFullYear() == year && (birthday.getMonth() + 1) == month && birthday.getDate() == day) {
            if (time >= 3 && time <= 100) {
                var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                var cardTemp = 0,
                    i, valnum;
                for (i = 0; i < 17; i++) {
                    cardTemp += humanId.substr(i, 1) * arrInt[i];
                }
                valnum = arrCh[cardTemp % 11];
                if (valnum == humanId.substr(17, 1)) {
                    return true;
                }
                return false;
            }
            return false;
        }
        return false;
    }
}


//严格版银行卡卡号校验（16-19位）
function checkBanknumber2(bankCard) {
    var num = /^\d*$/;
    var strBin = "10,18,30,35,37,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,58,60,62,65,68,69,84,87,88,94,95,98,99";
    if (bankCard.length < 16 || bankCard.length > 19) {
        return false; //位数
    } else if (!num.exec(bankCard)) {
        return false; //数字
    } else if (strBin.indexOf(bankCard.substring(0, 2)) == -1) {
        return false; //前6位校验
    } else {
        var lastNum = bankCard.substr(bankCard.length - 1, 1); //取出最后一位（与luhm进行比较）
        var first15Num = bankCard.substr(0, bankCard.length - 1); //前15或18位
        var newArr = new Array();
        for (var i = first15Num.length - 1; i > -1; i--) { //前15或18位倒序存进数组
            newArr.push(first15Num.substr(i, 1));
        }
        var arrJiShu = new Array(); //奇数位*2的积 <9
        var arrJiShu2 = new Array(); //奇数位*2的积 >9
        var arrOuShu = new Array(); //偶数位数组
        for (var j = 0; j < newArr.length; j++) {
            if ((j + 1) % 2 == 1) { //奇数位
                if (parseInt(newArr[j]) * 2 < 9)
                    arrJiShu.push(parseInt(newArr[j]) * 2);
                else
                    arrJiShu2.push(parseInt(newArr[j]) * 2);
            } else //偶数位
                arrOuShu.push(newArr[j]);
        }
        var jishu_child1 = new Array(); //奇数位*2 >9 的分割之后的数组个位数
        var jishu_child2 = new Array(); //奇数位*2 >9 的分割之后的数组十位数
        for (var h = 0; h < arrJiShu2.length; h++) {
            jishu_child1.push(parseInt(arrJiShu2[h]) % 10);
            jishu_child2.push(parseInt(arrJiShu2[h]) / 10);
        }
        var sumJiShu = 0; //奇数位*2 < 9 的数组之和
        var sumOuShu = 0; //偶数位数组之和
        var sumJiShuChild1 = 0; //奇数位*2 >9 的分割之后的数组个位数之和
        var sumJiShuChild2 = 0; //奇数位*2 >9 的分割之后的数组十位数之和
        var sumTotal = 0;
        for (var m = 0; m < arrJiShu.length; m++) {
            sumJiShu = sumJiShu + parseInt(arrJiShu[m]);
        }
        for (var n = 0; n < arrOuShu.length; n++) {
            sumOuShu = sumOuShu + parseInt(arrOuShu[n]);
        }
        for (var p = 0; p < jishu_child1.length; p++) {
            sumJiShuChild1 = sumJiShuChild1 + parseInt(jishu_child1[p]);
            sumJiShuChild2 = sumJiShuChild2 + parseInt(jishu_child2[p]);
        }
        //计算总和
        sumTotal = parseInt(sumJiShu) + parseInt(sumOuShu) + parseInt(sumJiShuChild1) + parseInt(sumJiShuChild2);
        //计算Luhm值
        var k = parseInt(sumTotal) % 10 == 0 ? 10 : parseInt(sumTotal) % 10;
        var luhm = 10 - k;
        if (lastNum == luhm) {
            return true;
        }
    }
    return false;
}


function ajax(url, opts, callBack, errorBack) {
    opts = opts || {};

    $.ajax({
        url: url,
        type: opts.type || 'POST',
        data: JSON.stringify(opts.data) || {},
        dataType: opts.dataType || 'json',
        contentType: "application/json",
        async: opts.async || true,
        success: callBack || ajaxBack,
        error: function(D) {
            ajaxNone(D);
            if (errorBack) errorBack();
        }
    });
}

function ajaxNone() {
    $.alert("系统错误请稍后再试！");
    return false;
}

function ajaxBack(D) {
    $.alert("系统错误请稍后再试！");
    return false;
}




//地区选择器
$(".selectcity").cityPicker({
    toolbarTemplate: '<header class="bar bar-nav">\
    <button class="button button-link pull-right close-picker">确定</button>\
    <h1 class="title">选择地区</h1>\
    </header>'
});
//基本信息提交

$(".msgsubmit").click(function () {
    var msg = $(this).parent().find("input");
    var data = {
        address : msg[0].value.split(" "),
        thoroughAddress : msg[1].value,
        HouseholdRegistration : msg[2].value,
        income : msg[3].value,
        company : msg[4].value,
        companyAddress : msg[5].value.split(" "),
        thoroughCompany : msg[6].value,
        school : msg[7].value,
        schoolTime : msg[8].value
    }
    if(data.address!=='' && data.thoroughAddress!==''&& data.HouseholdRegistration!=="" &&data.income!==''
        &&data.company!==''&&data.companyAddress!==''&&data.thoroughCompany!=="") {
        const userdata = {
            "userId": window.sessionStorage.userId,
            "merchantId": window.sessionStorage.merchantid,
            "quota": 0,
            "annualEarning":data.income,
            "householdAddress" :  data.HouseholdRegistration,//户籍地址
            "productType" : "1001",
            "childSchool" : {
                "title" : data.school,
                "startDate" : data.schoolTime,
            },
            "residentInfo": {
                //居住地址
                "liveAddr": {"province": data.address[0], "city": data.address[1], "district": data.address[2]},
                "specificAddr": data.thoroughAddress,//居住详细地址
            },
            "workInfo" :{
                //工作信息

                "workName": data.company, //公司名称
                //工作地址
                "workAddr": { "province": data.companyAddress[0], "city": data.companyAddress[1], "district": data.companyAddress[2] }, //公司地址
                "specificAddr":data.thoroughCompany,//公司详细地址
            },
        }
        $.ajax({
            url: javahost + "cashloan/submitDetailInfo",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(userdata),
            success: function(data) {
                if(data.statusCode != 200){
                    $.toast(data.message)
                }else{
                    $.toast(data.message)
                    $.router.load("#completedetails");
                }

            }
        });
    }else {
        $.alert('请完善个人信息');
    }

});



//联系人==亲属关系选择
function relationList(data){
    let stagesList = "";
    for(var i = 0; i<data.length; i++){
        if(data.length===3){
            stagesList += '<li class="list-data close-popup" data-id ='+ data[i].key+ ' onclick="selectRelation($(this))">' +
                data[i].relation
            '</li>';
        } else {
            stagesList += '<li class="list-data close-popup" data-id ='+ data[i].key+ ' onclick="selectFriendRelation($(this))">' +
                data[i].relation
            '</li>';
        };
        var content = '<div class="popup popup-order">'+
            '<h3>与本人关系<img class="close-popup" src="images/popClose@2x.png"></h3>'+
            '<ul>'+ stagesList +'</ul>'+
            '</div>';
        $.popup(content);
    }
}
$('#andRelation').click(()=>{
    const data = [
        {key: 2,relation: '父母'},
        {key: 1,relation: '夫妻'},
        {key: 3,relation: '子女'},
    ];
    relationList(data);
})
//联系人==朋友关系选择
$('#friendsRelation').click(()=>{
    const data = [
        {key: 7,relation: '同学'},
        {key: 6,relation: '朋友'},
        {key: 7,relation: '同事'},
        {key: 4,relation: '其他'},
    ];
    relationList(data);
})
//选择后 页面渲染
function selectRelation(value){
    const selectText = value[0].outerText;
    $('#andRelation').val(selectText);
};
function selectFriendRelation(value){
    const selectText = value[0].outerText;
    $('#friendsRelation').val(selectText);
};
//校验手机号码
function verifyMobile12(str) {
    return /^1[3,4,5,7,8]\d{9}$/.test(str);
}
//姓名有效性校验
function checkRealname12(humanName) {
    var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/
    return regName.test(humanName);

}
//联系人信息验证
function checkRelation(data) {
    if(data.contactInfo[0].relationType==''){
        $.toast('请选择直系亲属关系!');
        return false;
    }
    if(data.contactInfo[0].name==''){
        $.toast('请输入直系亲属名字!');
        return false;
    }
    if(!checkRealname12(data.contactInfo[0].name)){
        $.toast('请输入正确直系亲属名字!');
        return false;
    }

    if(data.contactInfo[0].phone==''){
        $.toast('请输入直系亲属关系电话号码!');
        return false;
    }
    if(!verifyMobile12(data.contactInfo[0].phone)){
        $.toast('请输入正确直系亲属电话号码!');
        return false;
    }

    if(data.contactInfo[1].relationType==''){
        $.toast('请选择朋友关系!');
        return false;
    }
    if(data.contactInfo[1].name==''){
        $.toast('请输入朋友名字!');
        return false;
    }
    if(!checkRealname12(data.contactInfo[1].name)){
        $.toast('请输入正确朋友名字!');
        return false;
    }

    if(data.contactInfo[1].phone==''){
        $.toast('请输入朋友关系电话号码!');
        return false;
    }

    if(!verifyMobile12(data.contactInfo[1].phone)){
        $.toast('请输入正确朋友电话号码!');
        return false;
    }

    return true;
};
//联系人提交
$('#relationSubmit').click(()=>{
    const andRelation = $('#andRelation').val();
    const andRelationName = $('#andRelationName').val();
    const andRelationNum = $('#andRelationNum').val();
    const friendsRelation = $('#friendsRelation').val();
    const friendName = $('#friendName').val();
    const friendNum = $('#friendNum').val();

    var relatives = "";
    var friend = "";

    if(andRelation == "父母"){
        relatives = 2
    }else if(andRelation == "子女"){
        relatives = 3
    }else if(andRelation == "夫妻"){
        relatives = 1
    }

    if(friendsRelation == "同学"){
        friend = 6
    }else if(friendsRelation == "朋友"){
        friend = 6
    }else if(friendsRelation == "同事"){
        friend = 7
    }else if(friendsRelation == "其他"){
        friend = 6
    }


    const data = {
        "userId": window.sessionStorage.userId,
        "productType" : "1001",
        "contactInfo": [{
            "rank" : "1",
            "name" :　andRelationName,
            "relationType":relatives ,
            "phone" :andRelationNum
        },{
            "rank" : "2",
            "name" :　friendName,
            "relationType":friend ,
            "phone" :friendNum
        }]
    }
    if(checkRelation(data)){
        ajax(timelyCfg.api.cashloanSubmitContactInfo, { "data": data }, function(D) {
            if (checkAjaxStart(D)) {
                if(D.statusCode == 200){
                    $.toast(D.message);
                    $.router.load("#completedetails");
                }
            }
        }, function(D) {

        });
    }
})





$(".amount").keyup(function () {
    const price = Number($('.price').html());
    const amount = Number($('.amount').val());
    if (amount > price) {
        $('.promptwarning').hide();
        $('.prompterror').show();
    } else {
        $('.promptwarning').show();
        $('.prompterror').hide();
    }
})

$("#VerEffectiveDate").calendar({
    value: ["2017-01-01 "]
});

$("#schooltime").calendar({
    value: ["2017-01-01 "]
});

//选取分期数额，页面添加详情
// 点击分期,选择期数
function selectStages(value) {
    const val = value.children()[1].innerHTML;
    $('#staging').val(val);
    $('.details').show();
    $('#everPrice').text(val);
}
// 分期详情
$(document).on('click', '.details', function() {
    const data = [
        {
            stages: '第一期',
            principal: 310,
            interest: 10,
        },
        {
            stages: '第一期',
            principal: 103,
            interest: 10,
        },
        {
            stages: '第一期',
            principal: 10,
            interest: 210,
        },
        {
            stages: '第一期',
            principal: 10,
            interest: 210,
        },
        {
            stages: '第一期',
            principal: 10,
            interest: 210,
        },
        {
            stages: '第一期',
            principal: 10,
            interest: 210,
        },
        {
            stages: '第一期',
            principal: 10,
            interest: 210,
        },
        {
            stages: '第一期',
            principal: 10,
            interest: 210,
        },
        {
            stages: '第一期',
            principal: 10,
            interest: 210,
        },
    ];
    let htmlCont = "";
    for(var i = 0; i<data.length; i++){
        htmlCont += '<li class="detailsData">' +
            '<span>'+ data[i].stages+'</span>'+
            '<span>'+ data[i].principal+'</span>'+
            '<span>'+ data[i].interest+'</span>'+
            '</li>';
    }
    $.modal({
        title: '<div class="detailsDialog">'+
        '<h3>分期详情<img class="closeDialog close-popup" src="images/popClose@2x.png"></h3>'+
        '<div>'+
        '<h5>总本金:￥45000 + 总手续费:￥3000</h5>'+
        '</div>'+
        '</div>',
        text: '<div class="dataList content-block">'+
        '<div class="header">' +
        '<span>期数</span>'+
        '<span>本金</span>'+
        '<span>手续费</span>'+
        '</div>'+
        '<ul>'+ htmlCont +'</ul>'+
        '</div>',
    })
    $(document).on('click', '.closeDialog', function() {
        $.closeModal('.modal');
    });
});

//获取利率
$(document).on("pageInit", function(e, pageId, $page) {

    if (pageId == "confirmation") {
        if(window.sessionStorage.classId == "" ||  window.sessionStorage.classPrice == ""){
            $.alert("请选择课程",function () {
                $.router.load("#selectlesson");
            })
            return;
        }
        $(".price").html(window.sessionStorage.classPrice);
        var data = {
            "coursewareId" : window.sessionStorage.classId
        };

        $.ajax({
            url: javahost4 + "hxx/getCourseStagesList",
            type: "post",
            dataType: "json",
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify(data),
            success: function(data) {
                console.log(data);
                // 点击分期,popUp显示
                $('#staging').click(()=>{
                    let stagesList = "";
                    for(var i = 0; i<data.data.stagesList.length; i++){
                        stagesList += '<li class="list-data close-popup" onclick="selectStages($(this))">' +
                            '<h4>'+ data.data.stagesList[i].loanRate+'</h4>'+
                            '<p>'+ data.data.stagesList[i].stagesCount+'</p>'+
                            '</li>';
                    };
                    var content = '<div class="popup popup-order">'+
                        '<h3>选择期数<img class="close-popup" src="images/popClose@2x.png"></h3>'+
                        '<ul>'+ stagesList +'</ul>'+
                        '</div>';
                    $.popup(content);
                });
            }
        });
    }
});


