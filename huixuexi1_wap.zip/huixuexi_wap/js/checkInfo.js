//地区选择器
$(".selectcity").cityPicker({
    toolbarTemplate: '<header class="bar bar-nav">\
    <button class="button button-link pull-right close-picker">确定</button>\
    <h1 class="title">选择地区</h1>\
    </header>'
});
//基本信息提交

$(".msgsubmit").click(function () {
   var msg = $(this).parent().find("input");
   var data = {
       address : msg[0].value.split(" "),
       thoroughAddress : msg[1].value,
       HouseholdRegistration : msg[2].value,
       income : msg[3].value,
       company : msg[4].value,
       companyAddress : msg[5].value.split(" "),
       thoroughCompany : msg[6].value,
       school : msg[7].value,
       schoolTime : msg[8].value
    }
    if(data.address!=='' && data.thoroughAddress!==''&& data.HouseholdRegistration!=="" &&data.income!==''
      &&data.company!==''&&data.companyAddress!==''&&data.thoroughCompany!=="") {
      const userdata = {
        "userId": window.sessionStorage.userId,
        "merchantId": window.sessionStorage.merchantid,
        "quota": 0,
        "basicInfo": {
          //居住地址
          "citypickerlive1":{ "province": data.address[0], "city": data.address[1], "district": data.address[2] },
          "liveDetailAddress": data.thoroughAddress,//居住详细地址
          "homeAddress": data.HouseholdRegistration,//户籍地址
          "monthIncome":data.income,//月收入
          "companyName": data.company, //公司名称
          //工作地址
          "citypickerliveadsArr": { "province": data.companyAddress[0], "city": data.companyAddress[1], "district": data.companyAddress[2] }, //公司地址
          "companyDetailAddress":data.thoroughCompany,//公司详细地址
        },
    }
      $.router.load('#verification3');
    }else {
      $.alert('请完善个人信息');
    }

});



// $('#workerBasicInfo').click(()=> {
//     const citypickerlive1 = $('#citypickerlive1').val().split(" ");
//     const liveDetailAddress = $('#liveDetailAddress').val();
//     const homeAddress = $('#homeAddress').val();
//     const monthIncome = $('#monthIncome').val();
//     const companyName = $('#companyName').val();
//     const citypickerliveadsArr = $('#citypickerworkads1').val().split(" ");
//     const companyDetailAddress = $('#companyDetailAddress').val();
//     if(citypickerlive1!=='' && liveDetailAddress!==''&& homeAddress!=="" &&monthIncome!==''
//       &&companyName!==''&&citypickerliveadsArr!==''&&companyName!==""&&companyDetailAddress!=="") {
//       const data = {
//         "userId": window.sessionStorage.userId,
//         "merchantId": window.sessionStorage.merchantid,
//         "quota": 0,
//         "basicInfo": {
//           //居住地址
//           "citypickerlive1":{ "province": citypickerlive1[0], "city": citypickerlive1[1], "district": citypickerlive1[2] },
//           "liveDetailAddress": liveDetailAddress,//居住详细地址
//           "homeAddress": homeAddress,//户籍地址
//           "monthIncome":monthIncome,//月收入
//           "companyName": companyName, //公司名称
//           //工作地址
//           "citypickerliveadsArr": { "province": citypickerliveadsArr[0], "city": citypickerliveadsArr[1], "district": citypickerliveadsArr[2] }, //公司地址
//           "companyDetailAddress":companyDetailAddress,//公司详细地址
//         },
//     }
//       $.router.load('#verification3');
//     }else {
//       $.alert('请完善个人信息');
//     }
// });



  //联系人==亲属关系选择
function relationList(data){
  let stagesList = "";
  for(var i = 0; i<data.length; i++){
    if(data.length===3){
      stagesList += '<li class="list-data" data-id ="data" onclick="selectRelation($(this))">' +
                      data[i].relation
                    '</li>';
    } else {
      stagesList += '<li class="list-data" data-id ="data" onclick="selectFriendRelation($(this))">' +
                      data[i].relation
                    '</li>';
    };          
    var content = '<div class="popup popup-order">'+
                    '<h3>与本人关系<img class="close-popup" src="images/popClose@2x.png"></h3>'+
                      '<ul>'+ stagesList +'</ul>'+
                  '</div>';
    $.popup(content);
  }
}
$('#andRelation').click(()=>{
  const data = [
    {key: 1,relation: '父母'},
    {key: 2,relation: '夫妻'},
    {key: 3,relation: '子女'},
  ];
  relationList(data);
})
 //联系人==朋友关系选择
$('#friendsRelation').click(()=>{
  const data = [
    {key: 1,relation: '同学'},
    {key: 2,relation: '朋友'},
    {key: 3,relation: '同事'},
    {key: 4,relation: '其他'},
  ];
  relationList(data);
})
//选择后 页面渲染
function selectRelation(value){
  const selectText = value[0].outerText;
  $('#andRelation').val(selectText);
};
function selectFriendRelation(value){
  const selectText = value[0].outerText;
  $('#friendsRelation').val(selectText);
};
//校验手机号码
function verifyMobile(str) {
  return /^1[3,4,5,7,8]\d{9}$/.test(str);
}
//姓名有效性校验
function checkRealname(humanName) {
    var regName = /^[\u4E00-\u9FA5\uF900-\uFA2D]{2,}(?:\·[\u4E00-\u9FA5\uF900-\uFA2D]{2,})*$/
    return regName.test(humanName);

}
//联系人信息验证
function checkRelation(data) {
  if(data.relationInfo.andRelation==''){
    $.toast('请选择直系亲属关系!');
    return false;
  }
  if(data.relationInfo.andRelationName==''){
    $.toast('请输入直系亲属名字!');
    return false;
  }else{
    if(!checkRealname(data.relationInfo.andRelationName)){
      $.toast('请输入正确直系亲属名字!');
      return false;
    }
  }
  if(data.relationInfo.andRelationNum==''){
    $.toast('请输入直系亲属关系电话号码!');
    return false;
  } else {
    if(!verifyMobile(data.relationInfo.andRelationNum)){
      $.toast('请输入正确直系亲属电话号码!');
      return false;
    }
  }
  if(data.relationInfo.friendsRelation==''){
    $.toast('请选择朋友关系!');
    return false;
  }
  if(data.relationInfo.friendName==''){
    $.toast('请输入朋友名字!');
    return false;
  }else{
    if(!checkRealname(data.relationInfo.friendName)){
      $.toast('请输入正确朋友名字!');
      return false;
    }else{
      return true;
    }
  }
  if(data.relationInfo.friendNum==''){
    $.toast('请输入朋友关系电话号码!');
    return false;
  }else{
    if(!verifyMobile(data.relationInfo.friendNum)){
      $.toast('请输入正确朋友电话号码!');
      return false;
    }
  }
  return true;
};
//联系人提交
$('#relationSubmit').click(()=>{
  const andRelation = $('#andRelation').val();
  const andRelationName = $('#andRelationName').val();
  const andRelationNum = $('#andRelationNum').val();
  const friendsRelation = $('#friendsRelation').val();
  const friendName = $('#friendName').val();
  const friendNum = $('#friendNum').val();
  const data = {
    "userId": window.sessionStorage.userId,
    "relationInfo": {
    "andRelation": andRelation,
    "andRelationName" : andRelationName,
    "andRelationNum" : andRelationNum,
    "friendsRelation" : friendsRelation,
    "friendName" : friendName,
    "friendNum" : friendNum,
    }
  }
  if(checkRelation(data)){
    $.router.load('#verification4');
  }
})